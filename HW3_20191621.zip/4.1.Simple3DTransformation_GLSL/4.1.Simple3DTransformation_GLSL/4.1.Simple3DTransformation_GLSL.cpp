#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/freeglut.h>

// Begin of shader setup
#include "Shaders/LoadShaders.h"
GLuint h_ShaderProgram; // handle to shader program
GLint loc_ModelViewProjectionMatrix, loc_primitive_color; // indices of uniform variables

typedef struct _Material_Parameters {
    float ambient_color[4], diffuse_color[4], specular_color[4], emissive_color[4];
    float specular_exponent;
} Material_Parameters;

#define N_TIGER_FRAMES 12
GLuint tiger_VBO, tiger_VAO;
int tiger_n_triangles[N_TIGER_FRAMES];
int tiger_vertex_offset[N_TIGER_FRAMES];
GLfloat* tiger_vertices[N_TIGER_FRAMES];

Material_Parameters material_tiger;

// ben object
#define N_BEN_FRAMES 30
GLuint ben_VBO, ben_VAO;
int ben_n_triangles[N_BEN_FRAMES];
int ben_vertex_offset[N_BEN_FRAMES];
GLfloat* ben_vertices[N_BEN_FRAMES];

Material_Parameters material_ben;

// wolf object
#define N_WOLF_FRAMES 17
GLuint wolf_VBO, wolf_VAO;
int wolf_n_triangles[N_WOLF_FRAMES];
int wolf_vertex_offset[N_WOLF_FRAMES];
GLfloat* wolf_vertices[N_WOLF_FRAMES];

Material_Parameters material_wolf;

// spider object
#define N_SPIDER_FRAMES 16
GLuint spider_VBO, spider_VAO;
int spider_n_triangles[N_SPIDER_FRAMES];
int spider_vertex_offset[N_SPIDER_FRAMES];
GLfloat* spider_vertices[N_SPIDER_FRAMES];

Material_Parameters material_spider;

int CCTV_E_FLAG = 0;
int TIGER_FLAG = 0;
int BIKE_FLAG = 0;
int GODZILLA_FLAG = 0;
int IRON_FLAG = 0;
float camera1_left = 0.0f;
float camera1_right = 0.0f;
float camera1_up = 0.0f;
float camera1_down = 0.0f;
int flag_7 = 0;
int flag_8 = 0;
int flag_9 = 0;
int flag_0 = 0;
int cur_frame_tiger = 0, cur_frame_ben = 0, cur_frame_wolf, cur_frame_spider = 0;
#define LOC_VERTEX 0
#define LOC_NORMAL 1
#define LOC_TEXCOORD 2

void initialize_camera();
void reshape(int, int);

void prepare_shader_program(void) {
    ShaderInfo shader_info[3] = {
       { GL_VERTEX_SHADER, "Shaders/simple.vert" },
       { GL_FRAGMENT_SHADER, "Shaders/simple.frag" },
       { GL_NONE, NULL }
    };

    h_ShaderProgram = LoadShaders(shader_info);
    glUseProgram(h_ShaderProgram);

    loc_ModelViewProjectionMatrix = glGetUniformLocation(h_ShaderProgram, "u_ModelViewProjectionMatrix");
    loc_primitive_color = glGetUniformLocation(h_ShaderProgram, "u_primitive_color");
}
// End of shader setup




// Begin of geometry setup
#define BUFFER_OFFSET(offset) ((GLvoid *) (offset))
#define INDEX_VERTEX_POSITION 0

GLuint axes_VBO, axes_VAO;
GLfloat axes_vertices[6][3] = {
   { 0.0f, 0.0f, 0.0f }, { 1.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, { 0.0f, 1.0f, 0.0f },
   { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }
};
GLfloat axes_color[3][3] = { { 1.0f, 0.0f, 0.0f }, { 0.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f } };

void prepare_axes(void) {
    // Initialize vertex buffer object.
    glGenBuffers(1, &axes_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, axes_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(axes_vertices), &axes_vertices[0][0], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &axes_VAO);
    glBindVertexArray(axes_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, axes_VBO);
    glVertexAttribPointer(INDEX_VERTEX_POSITION, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(INDEX_VERTEX_POSITION);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void draw_axes(void) {
    glBindVertexArray(axes_VAO);
    glUniform3fv(loc_primitive_color, 1, axes_color[0]);
    glDrawArrays(GL_LINES, 0, 2);
    glUniform3fv(loc_primitive_color, 1, axes_color[1]);
    glDrawArrays(GL_LINES, 2, 2);
    glUniform3fv(loc_primitive_color, 1, axes_color[2]);
    glDrawArrays(GL_LINES, 4, 2);
    glBindVertexArray(0);
}

#define N_OBJECTS 12
#define OBJECT_SQUARE16 0
#define OBJECT_TIGER 1
#define OBJECT_COW 2
#define OBJECT_BEN 3
#define OBJECT_DRAGON 4
#define OBJECT_SPIDER 5
#define OBJECT_WOLF 6
#define OBJECT_BUS 7
#define OBJECT_BIKE 8
#define OBJECT_GODZILLA 9
#define OBJECT_IRONMAN 10
#define OBJECT_TANK 11

GLuint object_VBO[N_OBJECTS], object_VAO[N_OBJECTS];
int object_n_triangles[N_OBJECTS];
GLfloat* object_vertices[N_OBJECTS];

int read_triangular_mesh(GLfloat** object, int bytes_per_primitive, char* filename) {
    int n_triangles;
    FILE* fp;

    fprintf(stdout, "Reading geometry from the geometry file %s...\n", filename);
    fp = fopen(filename, "rb");
    if (fp == NULL) {
        fprintf(stderr, "Cannot open the object file %s ...", filename);
        return -1;
    }
    fread(&n_triangles, sizeof(int), 1, fp);
    *object = (float*)malloc(n_triangles * bytes_per_primitive);
    if (*object == NULL) {
        fprintf(stderr, "Cannot allocate memory for the geometry file %s ...", filename);
        return -1;
    }

    fread(*object, bytes_per_primitive, n_triangles, fp);
    fprintf(stdout, "Read %d primitives successfully.\n\n", n_triangles);
    fclose(fp);

    return n_triangles;
}
int read_geometry(GLfloat** object, int bytes_per_primitive, char* filename) {
    int n_triangles;
    FILE* fp;

    // fprintf(stdout, "Reading geometry from the geometry file %s...\n", filename);
    fp = fopen(filename, "rb");
    if (fp == NULL) {
        fprintf(stderr, "Cannot open the object file %s ...", filename);
        return -1;
    }
    fread(&n_triangles, sizeof(int), 1, fp);

    *object = (float*)malloc(n_triangles * bytes_per_primitive);
    if (*object == NULL) {
        fprintf(stderr, "Cannot allocate memory for the geometry file %s ...", filename);
        return -1;
    }

    fread(*object, bytes_per_primitive, n_triangles, fp);
    // fprintf(stdout, "Read %d primitives successfully.\n\n", n_triangles);
    fclose(fp);

    return n_triangles;
}

void set_up_object(int object_ID, char* filename, int n_bytes_per_vertex) {
    object_n_triangles[object_ID] = read_triangular_mesh(&object_vertices[object_ID],
        3 * n_bytes_per_vertex, filename);
    // Error checking is needed here.

    // Initialize vertex buffer object.
    glGenBuffers(1, &object_VBO[object_ID]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[object_ID]);
    glBufferData(GL_ARRAY_BUFFER, object_n_triangles[object_ID] * 3 * n_bytes_per_vertex,
        object_vertices[object_ID], GL_STATIC_DRAW);

    // As the geometry data exists now in graphics memory, ...
    free(object_vertices[object_ID]);

    // Initialize vertex array object.
    glGenVertexArrays(1, &object_VAO[object_ID]);
    glBindVertexArray(object_VAO[object_ID]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[object_ID]);
    glVertexAttribPointer(INDEX_VERTEX_POSITION, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(INDEX_VERTEX_POSITION);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void prepare_square(void) {
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
    set_up_object(OBJECT_SQUARE16, "Data/Square16_triangles_vnt.geom", 8 * sizeof(float));
    
}

void prepare_tiger(void) {
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
    int i, n_bytes_per_vertex, n_bytes_per_triangle, tiger_n_total_triangles = 0;

  //  set_up_object(OBJECT_TIGER, "Data/Tiger_00_triangles_vnt.geom", 8 * sizeof(float));
    char filename[512];
    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;
    for (int i = 0; i < 12;i++) {
        sprintf(filename, "Data/dynamic_objects/tiger/Tiger_%d%d_triangles_vnt.geom", i / 10, i % 10);
        tiger_n_triangles[i] = read_geometry(&tiger_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        tiger_n_total_triangles += tiger_n_triangles[i];
        set_up_object(OBJECT_TIGER, filename, 8 * sizeof(float));

        if (i == 0)
            tiger_vertex_offset[i] = 0;
        else
            tiger_vertex_offset[i] = tiger_vertex_offset[i - 1] + 3 * tiger_n_triangles[i - 1];

    }
    glGenBuffers(1, &tiger_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, tiger_VBO);
    glBufferData(GL_ARRAY_BUFFER, tiger_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_TIGER_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, tiger_vertex_offset[i] * n_bytes_per_vertex,
            tiger_n_triangles[i] * n_bytes_per_triangle, tiger_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_TIGER_FRAMES; i++)
        free(tiger_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &tiger_VAO);
    glBindVertexArray(tiger_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, tiger_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void prepare_cow(void) {
    // 3 = 3 for vertex
    set_up_object(OBJECT_COW, "Data/Cow_triangles_v.geom", 3 * sizeof(float));
}

void prepare_ben(void) {
    // 3 for vertex, 3 for normal, and 2 for texcoord
    int i, n_bytes_per_vertex, n_bytes_per_triangle, ben_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_BEN_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/ben/ben_vn%d%d.geom", i / 10, i % 10);
        ben_n_triangles[i] = read_geometry(&ben_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        ben_n_total_triangles += ben_n_triangles[i];

        if (i == 0)
            ben_vertex_offset[i] = 0;
        else
            ben_vertex_offset[i] = ben_vertex_offset[i - 1] + 3 * ben_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &ben_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, ben_VBO);
    glBufferData(GL_ARRAY_BUFFER, ben_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_BEN_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, ben_vertex_offset[i] * n_bytes_per_vertex,
            ben_n_triangles[i] * n_bytes_per_triangle, ben_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_BEN_FRAMES; i++)
        free(ben_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &ben_VAO);
    glBindVertexArray(ben_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, ben_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void prepare_spider(void) {
    int i, n_bytes_per_vertex, n_bytes_per_triangle, spider_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_SPIDER_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
        spider_n_triangles[i] = read_geometry(&spider_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        spider_n_total_triangles += spider_n_triangles[i];

        if (i == 0)
            spider_vertex_offset[i] = 0;
        else
            spider_vertex_offset[i] = spider_vertex_offset[i - 1] + 3 * spider_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &spider_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, spider_VBO);
    glBufferData(GL_ARRAY_BUFFER, spider_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_SPIDER_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, spider_vertex_offset[i] * n_bytes_per_vertex,
            spider_n_triangles[i] * n_bytes_per_triangle, spider_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_SPIDER_FRAMES; i++)
        free(spider_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &spider_VAO);
    glBindVertexArray(spider_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, spider_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void prepare_dragon(void) {
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
    set_up_object(OBJECT_DRAGON, "Data/static_objects/dragon_vnt.geom", 8 * sizeof(float));
}

void prepare_tank(void) {
    set_up_object(OBJECT_TANK, "Data/static_objects/tank_vnt.geom", 8 * sizeof(float));
}

void prepare_godzilla(void) {
    set_up_object(OBJECT_GODZILLA, "Data/static_objects/godzilla_vnt.geom", 8 * sizeof(float));
}

void prepare_bus(void) {
    set_up_object(OBJECT_BUS, "Data/static_objects/bus_vnt.geom", 8 * sizeof(float));
}

void prepare_wolf(void) {
    int i, n_bytes_per_vertex, n_bytes_per_triangle, wolf_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_WOLF_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/wolf/wolf_%02d_vnt.geom", i);
        wolf_n_triangles[i] = read_geometry(&wolf_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        wolf_n_total_triangles += wolf_n_triangles[i];

        if (i == 0)
            wolf_vertex_offset[i] = 0;
        else
            wolf_vertex_offset[i] = wolf_vertex_offset[i - 1] + 3 * wolf_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &wolf_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, wolf_VBO);
    glBufferData(GL_ARRAY_BUFFER, wolf_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_WOLF_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, wolf_vertex_offset[i] * n_bytes_per_vertex,
            wolf_n_triangles[i] * n_bytes_per_triangle, wolf_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_WOLF_FRAMES; i++)
        free(wolf_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &wolf_VAO);
    glBindVertexArray(wolf_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, wolf_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void prepare_bike(void) {
    set_up_object(OBJECT_BIKE, "Data/static_objects/bike_vnt.geom", 8 * sizeof(float));
}

void prepare_ironman(void) {
    set_up_object(OBJECT_IRONMAN, "Data/static_objects/ironman_vnt.geom", 8 * sizeof(float));
}

void draw_tiger(void) {
    glUniform3f(loc_primitive_color, 165.0f / 255.0f, 042.0f / 255.0f, 042.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(tiger_VAO);
    glDrawArrays(GL_TRIANGLES, tiger_vertex_offset[cur_frame_tiger], 3 * tiger_n_triangles[cur_frame_tiger]);
    glBindVertexArray(0);
}
void draw_ben(void) {
    glUniform3f(loc_primitive_color, 100.0f / 255.0f, 149.0f / 255.0f, 237.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(ben_VAO);
    glDrawArrays(GL_TRIANGLES, ben_vertex_offset[cur_frame_ben], 3 * ben_n_triangles[cur_frame_ben]);
    glBindVertexArray(0);
}
void draw_wolf(void) {
    glUniform3f(loc_primitive_color, 105.0f / 255.0f, 105.0f / 255.0f, 105.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(wolf_VAO);
    glDrawArrays(GL_TRIANGLES, wolf_vertex_offset[cur_frame_wolf], 3 * wolf_n_triangles[cur_frame_wolf]);
    glBindVertexArray(0);
}
void draw_spider(void) {
    glUniform3f(loc_primitive_color, 047.0f / 255.0f, 079.0f / 255.0f, 079.0f / 255.0f);
   
    glFrontFace(GL_CW);
   
    glBindVertexArray(spider_VAO);
    glDrawArrays(GL_TRIANGLES, spider_vertex_offset[cur_frame_spider], 3 * spider_n_triangles[cur_frame_spider]);
    glBindVertexArray(0);
}
void draw_object(int object_ID, float r, float g, float b) {
    glUniform3f(loc_primitive_color, r, g, b);
    glBindVertexArray(object_VAO[object_ID]);
    glDrawArrays(GL_TRIANGLES, 0, 3 * object_n_triangles[object_ID]);
    glBindVertexArray(0);
}
// End of geometry setup

// Begin of Callback function definitions
#define TO_RADIAN 0.01745329252f  
#define TO_DEGREE 57.295779513f

// include glm/*.hpp only if necessary
// #include <glm/glm.hpp> 
#include <glm/gtc/matrix_transform.hpp> //translate, rotate, scale, lookAt, perspective, etc.
// ViewProjectionMatrix = ProjectionMatrix * ViewMatrix
glm::mat4 ViewProjectionMatrix, ViewMatrix, ProjectionMatrix;
// ModelViewProjectionMatrix = ProjectionMatrix * ViewMatrix * ModelMatrix
glm::mat4 ModelViewProjectionMatrix; // This one is sent to vertex shader when ready.
glm::vec3 lookat_u;
glm::vec3 lookat_v;
glm::vec3 lookat_n;
glm::vec3 VRP;
glm::vec3 VUP;
glm::vec3 PRP;
glm::vec3 VPN;
glm::mat4 Projection2;
glm::mat3 RotateM;
float angle_u = 0.0f;
float angle_v = 0.0f;
float angle_n = 0.0f;
float camX;
float camY;
float camZ;
int flag_a = 0;
typedef struct _Camera {
    glm::vec3 pos;
    glm::vec3 uaxis, vaxis, naxis;

    float fovy, aspect_ratio, near_c, far_c;
    int move;
} Camera;
Camera camera_wv;
enum _CameraType { CAMERA_WORLD_VIEWER, CAMERA_DRIVER } camera_type;

float fovy=15.0f;
float aspect;
float zNear=5.0f;
float zFar=100.0f;
float iron_clock;
float bike_clock;
float godzilla_clock;
float tiger_clock;
float rotation_angle_tiger = 0.0f, rotation_angle_cow = 0.0f;
float rotation_angle_iron;
int flag_fill_floor = 0;
int sky_flag = 0;
int zoom_flag = 0;
int flag_n = 0;
int flag_v = 0;
int flag_u = 0;
void display(void) {
  //  glClearColor(051.0f / 255.0f, 051.0f / 255.0f, 051.0f / 225.0f, 1.0f);
    
    
    if (sky_flag == 1) {
        glClearColor(51.0f / 255.0f, 051.0f / 255.0f, 051.0f / 225.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
    else {
        glClearColor(204 / 255.0f, 204 / 255.0f, 204 / 255.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix, glm::vec3(9.5f, 7.7f, 7.2f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.0f, 1.0f, 1.0f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    draw_axes();
    glLineWidth(1.0f);

   
    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix, glm::vec3(9.5f, 7.7f, 7.2f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(3.5f, 3.5f, 3.5f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix,
        90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    //  draw_axes();
    glLineWidth(1.0f);
    if (flag_fill_floor == 1)
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    draw_object(OBJECT_SQUARE16, 255.0f / 255.0f, 218.0f / 255.0f, 185.0f / 225.0f); // Light Sky Blue
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
   

    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(10.10f, 8.5f, 5.1f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 150.0f * TO_RADIAN,
        glm::vec3(0.0f, 0.0f, 1.0f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -20.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 30.0f * TO_RADIAN,
        glm::vec3(1.0f, 0.0f, 0.0f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.5f, 1.5f, 1.5f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_COW, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // Ȳ���ڸ� - ����


    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(11.5f, 7.7f, 8.6f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.03f, 0.03f, 0.03f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
        glm::vec3(1.0f, 0.0f, 0.0f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_DRAGON, 102 / 255.0f, 51 / 255.0f, 153 / 255.0f); // ��� �߽� - ����

    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(9.10f, 8.2f, 9.1f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 200.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));

    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.008f, 0.008f, -0.008f));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_GODZILLA, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // GODZILLA ���ڸ� - ����


    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(9.10f, 8.9f, 7.1f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.3f, 0.3f, 0.3f));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_IRONMAN, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // �ֵ����ڸ� - ����


    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(10.10f, 7.7f, 10.1f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 30.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.05f, 0.05f, 0.05f));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_BUS, 250 / 255.0f, 128 / 255.0f, 114 / 255.0f); // ���� - ����


    if (TIGER_FLAG == 1) {

    }
    else {
        tiger_clock++;
        if (tiger_clock == 360) {
            tiger_clock = 0;
        }
    }

        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(11.5f, 7.7f, 8.6f));
        ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix,
            -tiger_clock * TO_RADIAN * 10, glm::vec3(0.0f, 1.0f, 0.0f));

        ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
            glm::vec3(0.0f, 1.0f, 0.0f));
        ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewProjectionMatrix = glm::translate(ModelViewProjectionMatrix,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.006f, 0.006f, 0.006f));

        glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glLineWidth(3.0f);
        glLineWidth(1.0f);
        draw_tiger();
     
        //ȣ���̱׸��� - ������ü
    

    
        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(9.5f, 7.7f, 7.8f));
       
        if (IRON_FLAG == 1) {

        }
        else {
            iron_clock++;
            if (iron_clock == 30) {
                iron_clock = 0;
            }
        }
        if (iron_clock <= 15) {
            ModelViewProjectionMatrix = glm::translate(ModelViewProjectionMatrix, glm::vec3((float)(iron_clock * 2) * 0.1, sinf(iron_clock * 24 * TO_RADIAN), 0.0f));
        }
        else {
            ModelViewProjectionMatrix = glm::translate(ModelViewProjectionMatrix, glm::vec3(6 - (float)(iron_clock * 2) * 0.1 - 0.2, sinf(iron_clock * 24 * TO_RADIAN), 0.0f));
        }
        ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 180.0f * TO_RADIAN,
            glm::vec3(0.0f, 0.0f, 1.0f));
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(-1.1f, 1.1f, 1.1f));
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);

        glLineWidth(3.0f);
        glLineWidth(1.0f);
        draw_ben();
    
        //ben- ������ ��ü
    
        if (BIKE_FLAG == 1) {

        }
        else {
            bike_clock++;
            if (bike_clock == 360) {
                bike_clock = 0;
            }
        }
        
        
        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(11.5f, 7.7f, 9.6f));
        //bike_clock = bike_clock * 3;
        if (bike_clock <= 60) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f, 9.6f - 0.03 * bike_clock));
        }
        else if (bike_clock <= 120) {

            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f + (bike_clock - 60) * 0.03, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (bike_clock <= 180) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(13.5f - bike_clock * 0.01, 8.5f, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));

        }
        else if (bike_clock <= 240) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.9f, 9.2f - (bike_clock - 180) * 0.02, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (bike_clock <= 300) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.9f, 7.7f, 6.8f + 0.03 * (bike_clock - 240)));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }

        else {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f + 0.02 * (bike_clock - 300), 7.7f, 8.5f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 1.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        ModelViewProjectionMatrix = glm::translate(ModelViewProjectionMatrix,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.2f, -0.2f, -0.2f));
       
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glLineWidth(3.0f);
        glLineWidth(1.0f);
       
        draw_spider();
     
        //spider�׸��� - ������ü
    

        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(9.5f, 7.7f, 7.8f));
      
        if (GODZILLA_FLAG == 1) {
           
        }
        else {
            godzilla_clock++;
            if (godzilla_clock == 30) {
                godzilla_clock = 0;
            }
        }
      
        if (godzilla_clock <= 15) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f + godzilla_clock * 0.1, 10.5f));
        }
        else {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 9.2f - (godzilla_clock - 15) * 0.1, 10.5f));
        }
        
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.01f, 1.01f, 1.01f));
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);

        glLineWidth(3.0f);
        glLineWidth(1.0f);
        draw_wolf();
     
        //wolf - ������ ��ü

    



    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 27: // ESC key
        glutLeaveMainLoop(); // Incur destuction callback for cleanups.
        break;
        
    case 'f':
  
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        glutReshapeFunc(reshape);
 
        PRP = glm::vec3(23.0f, 15.0f, 17.0f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 1.0f, 0.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
        
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
     
        break;
        
    case 'a':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(20.0f, 7.7f, 15.0f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 1.0f, 0.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
       
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 1;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
        
    case '7':
        if (flag_a == 1) {
            camera1_left += 0.3f;

           
            VRP = VRP - camera1_left * lookat_u;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
            
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 1;
            flag_8 = 0;
            flag_9 = 0;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '8':
        if (flag_a == 1) {
            camera1_right += 0.3f;

       
            VRP = VRP + camera1_right * lookat_u;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
          
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 1;
            flag_9 = 0;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '9':
        if (flag_a == 1) {
            camera1_up += 0.3f;

           
            VRP = VRP + camera1_up * lookat_v;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
           
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 0;
            flag_9 = 1;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '0':
        if (flag_a == 1) {
            camera1_down += 0.3f;

            VRP = VRP - camera1_down * lookat_v;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
           
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 0;
            flag_9 = 0;
            flag_0 = 1;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case 'b':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
    
        PRP = glm::vec3(15.0f, 7.2f, 13.0f);
        VRP = glm::vec3(5.5f, 9.7f, 5.2f);
        VUP = glm::vec3(0.0f, 1.0f, 0.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
      
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
    
    case 'c':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(9.5f, 50.7f, 7.2f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 0.0f, 1.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
        
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
    
    case 'd':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(9.5f, -10.7f, 7.2f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 0.0f, 1.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
       
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
   
        
    case 't':
        sky_flag = 1 - sky_flag;
        break;
    case 'n':
    
        angle_n = angle_n + 0.1f;
       
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_n* TO_RADIAN, lookat_n));
        lookat_u = RotateM * lookat_u;
        lookat_v = RotateM * lookat_v;
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 1;
        flag_v = 0;
        flag_u = 0;
        break;


    
    case 'u':
      
        angle_u = angle_u + 0.1f;
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_u * TO_RADIAN, lookat_u));
        lookat_v = RotateM * lookat_v;
        lookat_n = RotateM * lookat_n;
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 1;
        break;
        
    case 'v':
      
        angle_v = angle_v + 0.1f;
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_v*TO_RADIAN, lookat_v));
        lookat_u = RotateM * lookat_u;
        lookat_n = RotateM * lookat_n;
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 1;
        flag_u = 0;
        break;
        

        
    case 'i':
      
        PRP = PRP + 1.0f * lookat_v;
        VRP = VRP + 1.0f * lookat_v;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    case 'j':
        
        PRP = PRP - 1.0f * lookat_u;
        VRP = VRP - 1.0f * lookat_u;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;

    case 'l':
       
        PRP = PRP + 1.0f * lookat_u;
        VRP = VRP + 1.0f * lookat_u;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    case 'k':
       
        PRP = PRP - 1.0f * lookat_v;
        VRP = VRP - 1.0f * lookat_v;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    case 'o':
      
        PRP = PRP - 1.0f * lookat_n;
        VRP = VRP - 1.0f * lookat_n;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;

    case 'p':
      
        PRP = PRP + 1.0f * lookat_n;
        VRP = VRP + 1.0f * lookat_n;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    case 'q':
        //zoom in
        zoom_flag = 1;
       
        zFar = zFar + 2;
        fovy = fovy - 2;
        if (fovy < 2) {
            fovy = 2;
        }
        ProjectionMatrix = glm::perspective(fovy*TO_RADIAN, aspect,zNear, zFar);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;

    case 'w':
        //zoom out
        zFar = zFar - 2;
       
        fovy = fovy + 2;
        if (fovy > 180) {
            fovy = 178;
        }
        ProjectionMatrix = glm::perspective(fovy * TO_RADIAN, aspect, zNear, zFar);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    
    case '1':
        if (TIGER_FLAG == 1) {
            TIGER_FLAG = 0;
        }
        else {
            TIGER_FLAG = 1;
        }
        break;
    case '2':
        printf("2");
        if (GODZILLA_FLAG == 1) {
            GODZILLA_FLAG = 0;
        }
        else {
            GODZILLA_FLAG = 1;
        }
        break;
    case '3':
        if (BIKE_FLAG == 1) {
            BIKE_FLAG = 0;
        }
        else {
            BIKE_FLAG = 1;
        }
        break;
    case '4':
        if (IRON_FLAG == 1) {
            IRON_FLAG = 0;
        }
        else {
            IRON_FLAG = 1;
        }
        break;
    }
    

}
int prevx, prevy;



void mousepress(int button, int state, int x, int y) {
 
    if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN)) {
        flag_fill_floor = 1;
        glutPostRedisplay();
    }
    else if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_UP)) {
        flag_fill_floor = 0;
        glutPostRedisplay();
    }
   
}

void reshape(int width, int height) {
    float aspect_ratio;
    glViewport(0, 0, width, height);
    
    aspect_ratio = (float)width / height;
    aspect = aspect_ratio;
    ProjectionMatrix = glm::perspective(15.0f * TO_RADIAN, aspect_ratio, 1.0f, 1000.0f);
    Projection2 = ProjectionMatrix;
    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
    glutPostRedisplay();
}

void timer_scene(int timestamp_scene) {
  
   
    rotation_angle_tiger = (float)(timestamp_scene % 360);
    rotation_angle_cow = (float)(timestamp_scene % 181);
    cur_frame_tiger = timestamp_scene % N_TIGER_FRAMES;
    cur_frame_ben = timestamp_scene % N_BEN_FRAMES;
    cur_frame_wolf = timestamp_scene % N_WOLF_FRAMES;
    cur_frame_spider = timestamp_scene % N_SPIDER_FRAMES;
    
    glutPostRedisplay();

    glutTimerFunc(100, timer_scene, (timestamp_scene + 1) % INT_MAX);
}

void cleanup(void) {
    glDeleteVertexArrays(1, &axes_VAO);
    glDeleteBuffers(1, &axes_VBO);

    glDeleteVertexArrays(N_OBJECTS, object_VAO);
    glDeleteBuffers(N_OBJECTS, object_VBO);
}
// End of callback function definitions
#define CAM_TSPEED 0.05f


void set_ViewMatrix_for_world_viewer(void) {
    ViewMatrix = glm::mat4(camera_wv.uaxis.x, camera_wv.vaxis.x, camera_wv.naxis.x, 0.0f,
        camera_wv.uaxis.y, camera_wv.vaxis.y, camera_wv.naxis.y, 0.0f,
        camera_wv.uaxis.z, camera_wv.vaxis.z, camera_wv.naxis.z, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f);
    ViewMatrix = glm::translate(ViewMatrix, -camera_wv.pos);
}


void renew_cam_position(int del) {
    camera_wv.pos += CAM_TSPEED * del * (-camera_wv.naxis);
}

#define CAM_RSPEED 0.1f
void renew_cam_orientation_rotation_around_v_axis(int angle) {
    glm::mat3 RotationMatrix;

    RotationMatrix = glm::mat3(glm::rotate(glm::mat4(1.0f), CAM_RSPEED * TO_RADIAN * angle, camera_wv.vaxis));
    camera_wv.uaxis = RotationMatrix * camera_wv.uaxis;
    camera_wv.naxis = RotationMatrix * camera_wv.naxis;
}

void motion(int x, int y) {
    if (!camera_wv.move | (camera_type != CAMERA_WORLD_VIEWER))
        return;

    renew_cam_position(prevy - y);
    renew_cam_orientation_rotation_around_v_axis(prevx - x);

    prevx = x; prevy = y;

    set_ViewMatrix_for_world_viewer();
    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

    glutPostRedisplay();
}

void register_callbacks(void) {
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mousepress);
    glutReshapeFunc(reshape);
    glutMotionFunc(motion);
    glutTimerFunc(100, timer_scene, 0);
    glutCloseFunc(cleanup);
}

void initialize_OpenGL(void) {
    glClearColor(100 / 255.0f, 100 / 255.0f, 100 / 255.0f, 1.0f); // Gray
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    glEnable(GL_DEPTH_TEST);


 
    PRP = glm::vec3(23.0f, 15.0f, 17.0f);
    VRP = glm::vec3(9.5f, 7.7f, 7.2f);
    VUP = glm::vec3(0.0f, 1.0f, 0.0f);
    VPN = PRP - VRP;
    lookat_n = glm::normalize(VPN);
    lookat_u = glm::normalize(glm::cross(VUP, VPN));
    lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
   
    ViewMatrix = glm::lookAt(PRP,VRP, VUP);

}

void prepare_scene(void) {
    prepare_axes();
    prepare_square();
    prepare_tiger();
    prepare_cow();
    prepare_ben();
    prepare_dragon();
    prepare_tank();
    prepare_godzilla();
    prepare_ironman();
    prepare_bus();
    prepare_wolf();
    prepare_bike();
    prepare_spider();

}

void initialize_renderer(void) {
    register_callbacks();
    prepare_shader_program();
    initialize_OpenGL();
    prepare_scene();
    initialize_camera();
}

void initialize_glew(void) {
    GLenum error;

    glewExperimental = GL_TRUE;

    error = glewInit();
    if (error != GLEW_OK) {
        fprintf(stderr, "Error: %s\n", glewGetErrorString(error));
        exit(-1);
    }
    fprintf(stdout, "*********************************************************\n");
    fprintf(stdout, " - GLEW version supported: %s\n", glewGetString(GLEW_VERSION));
    fprintf(stdout, " - OpenGL renderer: %s\n", glGetString(GL_RENDERER));
    fprintf(stdout, " - OpenGL version supported: %s\n", glGetString(GL_VERSION));
    fprintf(stdout, "*********************************************************\n\n");
}

void print_message(const char* m) {
    fprintf(stdout, "%s\n\n", m);
}

void greetings(char* program_name, char messages[][256], int n_message_lines) {
    fprintf(stdout, "**************************************************************\n\n");
    fprintf(stdout, "  PROGRAM NAME: %s\n\n", program_name);
    fprintf(stdout, "    This program was coded for CSE4170 students\n");
    fprintf(stdout, "      of Dept. of Comp. Sci. & Eng., Sogang University.\n\n");

    for (int i = 0; i < n_message_lines; i++)
        fprintf(stdout, "%s\n", messages[i]);
    fprintf(stdout, "\n**************************************************************\n\n");

    initialize_glew();
}



void initialize_camera(void) {
    camera_type = CAMERA_WORLD_VIEWER;

    camera_wv.uaxis = glm::vec3(ViewMatrix[0].x, ViewMatrix[1].x, ViewMatrix[2].x);
    camera_wv.vaxis = glm::vec3(ViewMatrix[0].y, ViewMatrix[1].y, ViewMatrix[2].y);
    camera_wv.naxis = glm::vec3(ViewMatrix[0].z, ViewMatrix[1].z, ViewMatrix[2].z);
    camera_wv.pos = -(ViewMatrix[3].x * camera_wv.uaxis + ViewMatrix[3].y * camera_wv.vaxis + ViewMatrix[3].z * camera_wv.naxis);

    camera_wv.move = 0;
    camera_wv.fovy = 30.0f, camera_wv.aspect_ratio = 1.0f; camera_wv.near_c = 5.0f; camera_wv.far_c = 10000.0f;

    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

 
}




#define N_MESSAGE_LINES 2
void main(int argc, char* argv[]) {
    char program_name[64] = "Sogang CSE4170 (4.1) Simple 3D Transformations";
    char messages[N_MESSAGE_LINES][256] = { "    - Keys used: 'ESC'",
       "    - Mouse used: Left Butten Click"
    };

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutInitContextVersion(3, 3);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutCreateWindow(program_name);

    greetings(program_name, messages, N_MESSAGE_LINES);
    initialize_renderer();

    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
    glutMainLoop();
}