#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <FreeImage/FreeImage.h>
#pragma comment(lib,"FreeImage.lib")
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_inverse.hpp>

typedef struct _loc_LIGHT_Parameters {
    GLint light_on;
    GLint position;
    GLint ambient_color, diffuse_color, specular_color;
    GLint spot_direction;
    GLint spot_exponent;
    GLint spot_cutoff_angle;
    GLint loc_blind_effect;
    GLint light_attenuation_factors;
} loc_light_Parameters;


typedef struct _Light_Parameters {
    int light_on;
    float position[4];
    float ambient_color[4], diffuse_color[4], specular_color[4];
    float spot_direction[3];
    float spot_exponent;
    float spot_cutoff_angle;
    float loc_blind_effect;
    float light_attenuation_factors[4]; // produce this effect only if .w != 0.0f
} Light_Parameters;

Light_Parameters light[4];

GLint loc_ModelViewProjectionMatrix_PS, loc_ModelViewMatrix_PS, loc_ModelViewMatrixInvTrans_PS;
GLint loc_Light_Position, loc_Light_La, loc_Light_L;
GLint loc_Material_Ka, loc_Material_Kd, loc_Material_Ks, loc_Material_Shininess;
GLint loc_use_halfway_vector;
GLint loc_screen_effect, loc_screen_frequency, loc_screen_width;
GLint loc_blind_effect;
int use_halfway_vector = 0;
// Begin of shader setup
#include "Shaders/LoadShaders.h"
GLuint h_ShaderProgram; // handle to shader program
GLuint h_ShaderProgram_GS;
GLuint h_ShaderProgram_TXPS;
GLuint h_ShaderProgram_PS;
GLint loc_ModelViewProjectionMatrix_TXPS, loc_ModelViewMatrix_TXPS, loc_ModelViewMatrixInvTrans_TXPS;
GLint loc_global_ambient_color;
GLint loc_global_ambient_color_TXPS;
loc_light_Parameters loc_light[4];
loc_light_Parameters loc_light_TXPS[4];
GLint loc_ModelViewProjectionMatrix, loc_primitive_color; // indices of uniform variables
GLint loc_ModelViewProjectionMatrix_GS, loc_ModelViewMatrix_GS, loc_ModelViewMatrixInvTrans_GS;
GLint loc_texture, loc_flag_texture_mapping, loc_flag_fog;

glm::mat4 ViewProjectionMatrix, ViewMatrix, ProjectionMatrix;
// ModelViewProjectionMatrix = ProjectionMatrix * ViewMatrix * ModelMatrix
glm::mat4 ModelViewProjectionMatrix; // This one is sent to vertex shader when ready.
int flag_tiger_animation, flag_polygon_fill;

typedef struct _Material_Parameters {
    float ambient_color[4], diffuse_color[4], specular_color[4], emissive_color[4];
    float specular_exponent;
} Material_Parameters;

typedef struct _loc_Material_Parameters {
    GLint ambient_color, diffuse_color, specular_color, emissive_color;
    GLint specular_exponent;
} loc_Material_Parameters;

#define N_TIGER_FRAMES 12
GLuint tiger_VBO, tiger_VAO;
int tiger_n_triangles[N_TIGER_FRAMES];
int tiger_vertex_offset[N_TIGER_FRAMES];
GLfloat* tiger_vertices[N_TIGER_FRAMES];

Material_Parameters material_tiger;
Material_Parameters material_floor;

// ben object
#define N_BEN_FRAMES 30
GLuint ben_VBO, ben_VAO;
int ben_n_triangles[N_BEN_FRAMES];
int ben_vertex_offset[N_BEN_FRAMES];
GLfloat* ben_vertices[N_BEN_FRAMES];

Material_Parameters material_ben;

// wolf object
#define N_WOLF_FRAMES 17
GLuint wolf_VBO, wolf_VAO;
int wolf_n_triangles[N_WOLF_FRAMES];
int wolf_vertex_offset[N_WOLF_FRAMES];
GLfloat* wolf_vertices[N_WOLF_FRAMES];

Material_Parameters material_wolf;

// spider object
#define N_SPIDER_FRAMES 16
GLuint spider_VBO, spider_VAO;
int spider_n_triangles[N_SPIDER_FRAMES];
int spider_vertex_offset[N_SPIDER_FRAMES];
GLfloat* spider_vertices[N_SPIDER_FRAMES];

Material_Parameters material_spider;

GLuint rectangle_VBO, rectangle_VAO;
GLfloat rectangle_vertices[12][3] = {  // vertices enumerated counterclockwise
    { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 1.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f },
    { 1.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f },
    { 1.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }
};

Material_Parameters material_bus;
loc_Material_Parameters loc_material;
loc_Material_Parameters loc_material_TXPS;
int CCTV_E_FLAG = 0;
int TIGER_FLAG = 0;
int BIKE_FLAG = 0;
int GODZILLA_FLAG = 0;
int IRON_FLAG = 0;
float camera1_left = 0.0f;
float camera1_right = 0.0f;
float camera1_up = 0.0f;
float camera1_down = 0.0f;
int flag_7 = 0;
int flag_8 = 0;
int flag_9 = 0;
int flag_0 = 0;
int flag_f = 0;
int cur_frame_tiger = 0, cur_frame_ben = 0, cur_frame_wolf, cur_frame_spider = 0;
#define LOC_VERTEX 0
#define LOC_NORMAL 1
#define LOC_TEXCOORD 2

#define LOC_POSITION 0

glm::mat4 ModelViewMatrix;
glm::mat3 ModelViewMatrixInvTrans;

void initialize_camera();
void reshape(int, int);
void My_glTexImage2D_from_file(char* filename);

#define N_TEXTURES_USED 10
#define TEXTURE_ID_BUS 0
#define TEXTURE_ID_WOLF 1
#define TEXTURE_ID_FLOOR 2
GLuint texture_names[N_TEXTURES_USED];
int flag_texture_mapping;



void prepare_shader_program(void) {
    int i;
    char string[256];
    ShaderInfo shader_info[3] = {
       { GL_VERTEX_SHADER, "Shaders/simple.vert" },
       { GL_FRAGMENT_SHADER, "Shaders/simple.frag" },
       { GL_NONE, NULL }
    };
    ShaderInfo shader_info_GS[3] = {
        { GL_VERTEX_SHADER, "Shaders/Gouraud.vert" },
        { GL_FRAGMENT_SHADER, "Shaders/Gouraud.frag" },
        { GL_NONE, NULL }
    };
    ShaderInfo shader_info_TXPS[3] = {
        { GL_VERTEX_SHADER, "Shaders/Phong_Tx.vert" },
        { GL_FRAGMENT_SHADER, "Shaders/Phong_Tx.frag" },
        { GL_NONE, NULL }
    };
    ShaderInfo shader_info_PS[3] = {
        { GL_VERTEX_SHADER, "Shaders/Simple_Phong.vert" },
        { GL_FRAGMENT_SHADER, "Shaders/Simple_Phong.frag" },
        { GL_NONE, NULL }
    };


    h_ShaderProgram = LoadShaders(shader_info);
   // glUseProgram(h_ShaderProgram);
    loc_ModelViewProjectionMatrix = glGetUniformLocation(h_ShaderProgram, "u_ModelViewProjectionMatrix");
    loc_primitive_color = glGetUniformLocation(h_ShaderProgram, "u_primitive_color");

    h_ShaderProgram_GS = LoadShaders(shader_info_GS);
    loc_ModelViewProjectionMatrix_GS = glGetUniformLocation(h_ShaderProgram_GS, "u_ModelViewProjectionMatrix");
    loc_ModelViewMatrix_GS = glGetUniformLocation(h_ShaderProgram_GS, "u_ModelViewMatrix");
    loc_ModelViewMatrixInvTrans_GS = glGetUniformLocation(h_ShaderProgram_GS, "u_ModelViewMatrixInvTrans");

    loc_global_ambient_color = glGetUniformLocation(h_ShaderProgram_GS, "u_global_ambient_color");

    for (i = 0; i < 4; i++) {
        printf("iiii");
        sprintf(string, "u_light[%d].light_on", i);
        loc_light[i].light_on = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].position", i);
        loc_light[i].position = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].ambient_color", i);
        loc_light[i].ambient_color = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].diffuse_color", i);
        loc_light[i].diffuse_color = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].specular_color", i);
        loc_light[i].specular_color = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].spot_direction", i);
        loc_light[i].spot_direction = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].spot_exponent", i);
        loc_light[i].spot_exponent = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].spot_cutoff_angle", i);
        loc_light[i].spot_cutoff_angle = glGetUniformLocation(h_ShaderProgram_GS, string);
        sprintf(string, "u_light[%d].light_attenuation_factors", i);
        loc_light[i].light_attenuation_factors = glGetUniformLocation(h_ShaderProgram_GS, string);
    }

    loc_material.ambient_color = glGetUniformLocation(h_ShaderProgram_GS, "u_material.ambient_color");
    loc_material.diffuse_color = glGetUniformLocation(h_ShaderProgram_GS, "u_material.diffuse_color");
    loc_material.specular_color = glGetUniformLocation(h_ShaderProgram_GS, "u_material.specular_color");
    loc_material.emissive_color = glGetUniformLocation(h_ShaderProgram_GS, "u_material.emissive_color");
    loc_material.specular_exponent = glGetUniformLocation(h_ShaderProgram_GS, "u_material.specular_exponent");

    loc_screen_effect = glGetUniformLocation(h_ShaderProgram_GS, "screen_effect");
    loc_screen_frequency = glGetUniformLocation(h_ShaderProgram_GS, "screen_frequency");
    loc_screen_width = glGetUniformLocation(h_ShaderProgram_GS, "screen_width");

    loc_blind_effect = glGetUniformLocation(h_ShaderProgram_GS, "u_blind_effect");

    h_ShaderProgram_TXPS = LoadShaders(shader_info_TXPS);
    loc_ModelViewProjectionMatrix_TXPS = glGetUniformLocation(h_ShaderProgram_TXPS, "u_ModelViewProjectionMatrix");
    loc_ModelViewMatrix_TXPS = glGetUniformLocation(h_ShaderProgram_TXPS, "u_ModelViewMatrix");
    loc_ModelViewMatrixInvTrans_TXPS = glGetUniformLocation(h_ShaderProgram_TXPS, "u_ModelViewMatrixInvTrans");

    loc_global_ambient_color_TXPS = glGetUniformLocation(h_ShaderProgram_TXPS, "u_global_ambient_color");

   
    for (i = 0; i < 4; i++) {
        sprintf(string, "u_light[%d].light_on", i);
        loc_light_TXPS[i].light_on = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].position", i);
        loc_light_TXPS[i].position = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].ambient_color", i);
        loc_light_TXPS[i].ambient_color = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].diffuse_color", i);
        loc_light_TXPS[i].diffuse_color = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].specular_color", i);
        loc_light_TXPS[i].specular_color = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].spot_direction", i);
        loc_light_TXPS[i].spot_direction = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].spot_exponent", i);
        loc_light_TXPS[i].spot_exponent = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].spot_cutoff_angle", i);
        loc_light_TXPS[i].spot_cutoff_angle = glGetUniformLocation(h_ShaderProgram_TXPS, string);
        sprintf(string, "u_light[%d].light_attenuation_factors", i);
        loc_light_TXPS[i].light_attenuation_factors = glGetUniformLocation(h_ShaderProgram_TXPS, string);
    }
    
    loc_material_TXPS.ambient_color = glGetUniformLocation(h_ShaderProgram_TXPS, "u_material.ambient_color");
    loc_material_TXPS.diffuse_color = glGetUniformLocation(h_ShaderProgram_TXPS, "u_material.diffuse_color");
    loc_material_TXPS.specular_color = glGetUniformLocation(h_ShaderProgram_TXPS, "u_material.specular_color");
    loc_material_TXPS.emissive_color = glGetUniformLocation(h_ShaderProgram_TXPS, "u_material.emissive_color");
    loc_material_TXPS.specular_exponent = glGetUniformLocation(h_ShaderProgram_TXPS, "u_material.specular_exponent");

    loc_texture = glGetUniformLocation(h_ShaderProgram_TXPS, "u_base_texture");

    loc_flag_texture_mapping = glGetUniformLocation(h_ShaderProgram_TXPS, "u_flag_texture_mapping");
    loc_flag_fog = glGetUniformLocation(h_ShaderProgram_TXPS, "u_flag_fog");


    h_ShaderProgram_PS = LoadShaders(shader_info_PS);
    loc_ModelViewProjectionMatrix_PS = glGetUniformLocation(h_ShaderProgram_PS, "MVP");
    loc_ModelViewMatrix_PS = glGetUniformLocation(h_ShaderProgram_PS, "ModelViewMatrix");
    loc_ModelViewMatrixInvTrans_PS = glGetUniformLocation(h_ShaderProgram_PS, "NormalMatrix");

    loc_Light_Position = glGetUniformLocation(h_ShaderProgram_PS, "Light.Position");
    loc_Light_La = glGetUniformLocation(h_ShaderProgram_PS, "Light.La");
    loc_Light_L = glGetUniformLocation(h_ShaderProgram_PS, "Light.L");

    loc_Material_Ka = glGetUniformLocation(h_ShaderProgram_PS, "Material.Ka");
    loc_Material_Kd = glGetUniformLocation(h_ShaderProgram_PS, "Material.Kd");
    loc_Material_Ks = glGetUniformLocation(h_ShaderProgram_PS, "Material.Ks");
    loc_Material_Shininess = glGetUniformLocation(h_ShaderProgram_PS, "Material.Shininess");

    loc_use_halfway_vector = glGetUniformLocation(h_ShaderProgram_PS, "use_halfway_vector");

 
}
// End of shader setup




// Begin of geometry setup
#define BUFFER_OFFSET(offset) ((GLvoid *) (offset))
#define INDEX_VERTEX_POSITION 0

GLuint axes_VBO, axes_VAO;
GLfloat axes_vertices[6][3] = {
   { 0.0f, 0.0f, 0.0f }, { 1.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, { 0.0f, 1.0f, 0.0f },
   { 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 1.0f }
};
GLfloat axes_color[3][3] = { { 1.0f, 0.0f, 0.0f }, { 0.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, 1.0f } };

void prepare_axes(void) {
    // Initialize vertex buffer object.
    glGenBuffers(1, &axes_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, axes_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(axes_vertices), &axes_vertices[0][0], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &axes_VAO);
    glBindVertexArray(axes_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, axes_VBO);
    glVertexAttribPointer(INDEX_VERTEX_POSITION, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(INDEX_VERTEX_POSITION);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void draw_axes(void) {
    glBindVertexArray(axes_VAO);
    glUniform3fv(loc_primitive_color, 1, axes_color[0]);
    glDrawArrays(GL_LINES, 0, 2);
    glUniform3fv(loc_primitive_color, 1, axes_color[1]);
    glDrawArrays(GL_LINES, 2, 2);
    glUniform3fv(loc_primitive_color, 1, axes_color[2]);
    glDrawArrays(GL_LINES, 4, 2);
    glBindVertexArray(0);
}

#define N_OBJECTS 12
#define OBJECT_SQUARE16 0
#define OBJECT_TIGER 1
#define OBJECT_COW 2
#define OBJECT_BEN 3
#define OBJECT_DRAGON 4
#define OBJECT_SPIDER 5
#define OBJECT_WOLF 6
#define OBJECT_BUS 7
#define OBJECT_BIKE 8
#define OBJECT_GODZILLA 9
#define OBJECT_IRONMAN 10
#define OBJECT_TANK 11

GLuint object_VBO[N_OBJECTS], object_VAO[N_OBJECTS];
int object_n_triangles[N_OBJECTS];
GLfloat* object_vertices[N_OBJECTS];

int read_triangular_mesh(GLfloat** object, int bytes_per_primitive, char* filename) {
    int n_triangles;
    FILE* fp;

    fprintf(stdout, "Reading geometry from the geometry file %s...\n", filename);
    fp = fopen(filename, "rb");
    if (fp == NULL) {
        fprintf(stderr, "Cannot open the object file %s ...", filename);
        return -1;
    }
    fread(&n_triangles, sizeof(int), 1, fp);
    *object = (float*)malloc(n_triangles * bytes_per_primitive);
    if (*object == NULL) {
        fprintf(stderr, "Cannot allocate memory for the geometry file %s ...", filename);
        return -1;
    }

    fread(*object, bytes_per_primitive, n_triangles, fp);
    fprintf(stdout, "Read %d primitives successfully.\n\n", n_triangles);
    fclose(fp);

    return n_triangles;
}
int read_geometry(GLfloat** object, int bytes_per_primitive, char* filename) {
    int n_triangles;
    FILE* fp;

    // fprintf(stdout, "Reading geometry from the geometry file %s...\n", filename);
    fp = fopen(filename, "rb");
    if (fp == NULL) {
        fprintf(stderr, "Cannot open the object file %s ...", filename);
        return -1;
    }
    fread(&n_triangles, sizeof(int), 1, fp);

    *object = (float*)malloc(n_triangles * bytes_per_primitive);
    if (*object == NULL) {
        fprintf(stderr, "Cannot allocate memory for the geometry file %s ...", filename);
        return -1;
    }

    fread(*object, bytes_per_primitive, n_triangles, fp);
    // fprintf(stdout, "Read %d primitives successfully.\n\n", n_triangles);
    fclose(fp);

    return n_triangles;
}

void set_up_object(int object_ID, char* filename, int n_bytes_per_vertex) {
    object_n_triangles[object_ID] = read_triangular_mesh(&object_vertices[object_ID],
        3 * n_bytes_per_vertex, filename);
    // Error checking is needed here.

    // Initialize vertex buffer object.
    glGenBuffers(1, &object_VBO[object_ID]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[object_ID]);
    glBufferData(GL_ARRAY_BUFFER, object_n_triangles[object_ID] * 3 * n_bytes_per_vertex,
        object_vertices[object_ID], GL_STATIC_DRAW);

    // As the geometry data exists now in graphics memory, ...
    free(object_vertices[object_ID]);

    // Initialize vertex array object.
    glGenVertexArrays(1, &object_VAO[object_ID]);
    glBindVertexArray(object_VAO[object_ID]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[object_ID]);
    glVertexAttribPointer(INDEX_VERTEX_POSITION, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(INDEX_VERTEX_POSITION);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void prepare_floor(void) {
    /*
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
    //set_up_object(OBJECT_SQUARE16, "Data/Square16_triangles_vnt.geom", 8 * sizeof(float));
    
    object_n_triangles[OBJECT_SQUARE16] = read_triangular_mesh(&object_vertices[OBJECT_SQUARE16],
        3 * 8 * sizeof(float), "Data/Square16_triangles_vnt.geom");
    glGenBuffers(1, &object_VBO[OBJECT_SQUARE16]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_SQUARE16]);
    glBufferData(GL_ARRAY_BUFFER, object_n_triangles[OBJECT_SQUARE16] * 3 * 8 * sizeof(float), object_vertices[OBJECT_SQUARE16], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &object_VAO[OBJECT_SQUARE16]);
    glBindVertexArray(object_VAO[OBJECT_SQUARE16]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_SQUARE16]);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
 //   glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(6 * sizeof(float)));
  //  glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

        material_floor.ambient_color[0] = 0.2f;
        material_floor.ambient_color[1] = 0.1f;
        material_floor.ambient_color[2] = 0.1f;
        material_floor.ambient_color[3] = 1.0f;

        material_floor.diffuse_color[0] = 0.7f;
        material_floor.diffuse_color[1] = 0.5f;
        material_floor.diffuse_color[2] = 0.4f;
        material_floor.diffuse_color[3] = 1.0f;

        material_floor.specular_color[0] = 0.4f;
        material_floor.specular_color[1] = 0.7f;
        material_floor.specular_color[2] = 0.04f;
        material_floor.specular_color[3] = 1.0f;

        material_floor.specular_exponent = 51.5f;

        material_floor.emissive_color[0] = 0.1f;
        material_floor.emissive_color[1] = 0.1f;
        material_floor.emissive_color[2] = 0.0f;
        material_floor.emissive_color[3] = 1.0f;
    */
    glGenBuffers(1, &rectangle_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, rectangle_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(rectangle_vertices), &rectangle_vertices[0][0], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &rectangle_VAO);
    glBindVertexArray(rectangle_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, rectangle_VBO);
    glVertexAttribPointer(LOC_POSITION, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
  //  glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(6 * sizeof(float)));
   // glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    material_floor.ambient_color[0] = 0.2f;
    material_floor.ambient_color[1] = 0.05f;
    material_floor.ambient_color[2] = 0.07f;
    material_floor.ambient_color[3] = 1.0f;

    material_floor.diffuse_color[0] = 0.4f;
    material_floor.diffuse_color[1] = 0.5f;
    material_floor.diffuse_color[2] = 0.4f;
    material_floor.diffuse_color[3] = 1.0f;

    material_floor.specular_color[0] = 0.4f;
    material_floor.specular_color[1] = 0.7f;
    material_floor.specular_color[2] = 0.4f;
    material_floor.specular_color[3] = 1.0f;

    material_floor.specular_exponent = 500.5f;

    material_floor.emissive_color[0] = 0.1f;
    material_floor.emissive_color[1] = 0.1f;
    material_floor.emissive_color[2] = 0.0f;
    material_floor.emissive_color[3] = 1.0f;

    

}

void prepare_tiger(void) {
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
    int i, n_bytes_per_vertex, n_bytes_per_triangle, tiger_n_total_triangles = 0;

  //  set_up_object(OBJECT_TIGER, "Data/Tiger_00_triangles_vnt.geom", 8 * sizeof(float));
    char filename[512];
    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;
    for (int i = 0; i < 12;i++) {
        sprintf(filename, "Data/dynamic_objects/tiger/Tiger_%d%d_triangles_vnt.geom", i / 10, i % 10);
        tiger_n_triangles[i] = read_geometry(&tiger_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        tiger_n_total_triangles += tiger_n_triangles[i];
        set_up_object(OBJECT_TIGER, filename, 8 * sizeof(float));

        if (i == 0)
            tiger_vertex_offset[i] = 0;
        else
            tiger_vertex_offset[i] = tiger_vertex_offset[i - 1] + 3 * tiger_n_triangles[i - 1];

    }
    glGenBuffers(1, &tiger_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, tiger_VBO);
    glBufferData(GL_ARRAY_BUFFER, tiger_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_TIGER_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, tiger_vertex_offset[i] * n_bytes_per_vertex,
            tiger_n_triangles[i] * n_bytes_per_triangle, tiger_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_TIGER_FRAMES; i++)
        free(tiger_vertices[i]);

    // initialize vertex array object
    /*
    glGenVertexArrays(1, &tiger_VAO);
    glBindVertexArray(tiger_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, tiger_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    */
    glGenVertexArrays(1, &tiger_VAO);
    glBindVertexArray(tiger_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, tiger_VBO);
    glVertexAttribPointer(LOC_POSITION, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    material_tiger.ambient_color[0] = 0.24725f;
    material_tiger.ambient_color[1] = 0.1995f;
    material_tiger.ambient_color[2] = 0.0745f;
    material_tiger.ambient_color[3] = 1.0f;

    material_tiger.diffuse_color[0] = 151.0f/255.0f;
    material_tiger.diffuse_color[1] = 0.0f/255.0f;
    material_tiger.diffuse_color[2] = 0.0f;
    material_tiger.diffuse_color[3] = 1.0f;

    material_tiger.specular_color[0] = 0.628281f;
    material_tiger.specular_color[1] = 0.555802f;
    material_tiger.specular_color[2] = 0.366065f;
    material_tiger.specular_color[3] = 1.0f;

    material_tiger.specular_exponent = 51.2f;

    material_tiger.emissive_color[0] = 0.1f;
    material_tiger.emissive_color[1] = 0.1f;
    material_tiger.emissive_color[2] = 0.0f;
    material_tiger.emissive_color[3] = 1.0f;
}

void set_material_tiger(void) {
    // assume ShaderProgram_GS is used
    glUniform4fv(loc_material.ambient_color, 1, material_tiger.ambient_color);
    glUniform4fv(loc_material.diffuse_color, 1, material_tiger.diffuse_color);
    glUniform4fv(loc_material.specular_color, 1, material_tiger.specular_color);
    glUniform1f(loc_material.specular_exponent, material_tiger.specular_exponent);
    glUniform4fv(loc_material.emissive_color, 1, material_tiger.emissive_color);
}

void prepare_cow(void) {
    // 3 = 3 for vertex
    set_up_object(OBJECT_COW, "Data/Cow_triangles_v.geom", 3 * sizeof(float));
}

void prepare_ben(void) {
    // 3 for vertex, 3 for normal, and 2 for texcoord
    int i, n_bytes_per_vertex, n_bytes_per_triangle, ben_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_BEN_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/ben/ben_vn%d%d.geom", i / 10, i % 10);
        ben_n_triangles[i] = read_geometry(&ben_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        ben_n_total_triangles += ben_n_triangles[i];

        if (i == 0)
            ben_vertex_offset[i] = 0;
        else
            ben_vertex_offset[i] = ben_vertex_offset[i - 1] + 3 * ben_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &ben_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, ben_VBO);
    glBufferData(GL_ARRAY_BUFFER, ben_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_BEN_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, ben_vertex_offset[i] * n_bytes_per_vertex,
            ben_n_triangles[i] * n_bytes_per_triangle, ben_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_BEN_FRAMES; i++)
        free(ben_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &ben_VAO);
    glBindVertexArray(ben_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, ben_VBO);
  //  glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
  //  glEnableVertexAttribArray(0);
  //  glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
   // glEnableVertexAttribArray(1);

    
    glVertexAttribPointer(LOC_POSITION, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    material_ben.ambient_color[0] = 0.14725f;
    material_ben.ambient_color[1] = 0.01995f;
    material_ben.ambient_color[2] = 0.0745f;
    material_ben.ambient_color[3] = 1.0f;

    material_ben.diffuse_color[0] = 0.75164f;
    material_ben.diffuse_color[1] = 0.60648f;
    material_ben.diffuse_color[2] = 0.22648f;
    material_ben.diffuse_color[3] = 1.0f;

    material_ben.specular_color[0] = 0.628281f;
    material_ben.specular_color[1] = 0.555802f;
    material_ben.specular_color[2] = 0.366065f;
    material_ben.specular_color[3] = 1.0f;

    material_ben.specular_exponent = 51.2f;

    material_ben.emissive_color[0] = 0.1f;
    material_ben.emissive_color[1] = 0.1f;
    material_ben.emissive_color[2] = 0.0f;
    material_ben.emissive_color[3] = 1.0f;
}

void set_material_ben(void) {
    // assume ShaderProgram_GS is used
    glUniform4fv(loc_material.ambient_color, 1, material_ben.ambient_color);
    glUniform4fv(loc_material.diffuse_color, 1, material_ben.diffuse_color);
    glUniform4fv(loc_material.specular_color, 1, material_ben.specular_color);
    glUniform1f(loc_material.specular_exponent, material_ben.specular_exponent);
    glUniform4fv(loc_material.emissive_color, 1, material_ben.emissive_color);
}

void prepare_spider(void) {
    int i, n_bytes_per_vertex, n_bytes_per_triangle, spider_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_SPIDER_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/spider/spider_vnt_%d%d.geom", i / 10, i % 10);
        spider_n_triangles[i] = read_geometry(&spider_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        spider_n_total_triangles += spider_n_triangles[i];

        if (i == 0)
            spider_vertex_offset[i] = 0;
        else
            spider_vertex_offset[i] = spider_vertex_offset[i - 1] + 3 * spider_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &spider_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, spider_VBO);
    glBufferData(GL_ARRAY_BUFFER, spider_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_SPIDER_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, spider_vertex_offset[i] * n_bytes_per_vertex,
            spider_n_triangles[i] * n_bytes_per_triangle, spider_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_SPIDER_FRAMES; i++)
        free(spider_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &spider_VAO);
    glBindVertexArray(spider_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, spider_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}
void prepare_dragon(void) {
    // 8 = 3 for vertex, 3 for normal, and 2 for texcoord
   // set_up_object(OBJECT_DRAGON, "Data/static_objects/dragon_vnt.geom", 8 * sizeof(float));
    object_n_triangles[OBJECT_DRAGON] = read_triangular_mesh(&object_vertices[OBJECT_DRAGON],
        3 * 8 * sizeof(float), "Data/static_objects/dragon_vnt.geom");
    glGenBuffers(1, &object_VBO[OBJECT_DRAGON]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_DRAGON]);
    glBufferData(GL_ARRAY_BUFFER, object_n_triangles[OBJECT_DRAGON] * 3 * 8 * sizeof(float), object_vertices[OBJECT_DRAGON], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &object_VAO[OBJECT_DRAGON]);
    glBindVertexArray(object_VAO[OBJECT_DRAGON]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_DRAGON]);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);


}

void prepare_tank(void) {
    set_up_object(OBJECT_TANK, "Data/static_objects/tank_vnt.geom", 8 * sizeof(float));
}

void prepare_godzilla(void) {
    set_up_object(OBJECT_GODZILLA, "Data/static_objects/godzilla_vnt.geom", 8 * sizeof(float));
}

void prepare_bus(void) {
    // set_up_object(OBJECT_BUS, "Data/static_objects/bus_vnt.geom", 8 * sizeof(float));
    object_n_triangles[OBJECT_BUS] = read_triangular_mesh(&object_vertices[OBJECT_BUS],
        3 * 8 * sizeof(float), "Data/static_objects/bus_vnt.geom");
    glGenBuffers(1, &object_VBO[OBJECT_BUS]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_BUS]);
    glBufferData(GL_ARRAY_BUFFER, object_n_triangles[OBJECT_BUS] * 3 * 8 * sizeof(float), object_vertices[OBJECT_BUS], GL_STATIC_DRAW);

    // Initialize vertex array object.
    glGenVertexArrays(1, &object_VAO[OBJECT_BUS]);
    glBindVertexArray(object_VAO[OBJECT_BUS]);

    glBindBuffer(GL_ARRAY_BUFFER, object_VBO[OBJECT_BUS]);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    material_bus.ambient_color[0] = 0.0f;
    material_bus.ambient_color[1] = 0.05f;
    material_bus.ambient_color[2] = 0.0f;
    material_bus.ambient_color[3] = 1.0f;

    material_bus.diffuse_color[0] = 0.2f;
    material_bus.diffuse_color[1] = 0.5f;
    material_bus.diffuse_color[2] = 0.2f;
    material_bus.diffuse_color[3] = 1.0f;

    material_bus.specular_color[0] = 0.24f;
    material_bus.specular_color[1] = 0.5f;
    material_bus.specular_color[2] = 0.24f;
    material_bus.specular_color[3] = 1.0f;

    material_bus.specular_exponent = 2.5f;

    material_bus.emissive_color[0] = 0.0f;
    material_bus.emissive_color[1] = 0.0f;
    material_bus.emissive_color[2] = 0.0f;
    material_bus.emissive_color[3] = 1.0f;

    glHint(GL_GENERATE_MIPMAP_HINT, GL_NICEST);

    glActiveTexture(GL_TEXTURE0 + TEXTURE_ID_BUS);
    glBindTexture(GL_TEXTURE_2D, texture_names[TEXTURE_ID_BUS]);


    My_glTexImage2D_from_file("Data/busimage.jpg");

    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
}
void set_material_bus(void) {
    // assume ShaderProgram_TXPS is used
    glUniform4fv(loc_material_TXPS.ambient_color, 1, material_bus.ambient_color);
    glUniform4fv(loc_material_TXPS.diffuse_color, 1, material_bus.diffuse_color);
    glUniform4fv(loc_material_TXPS.specular_color, 1, material_bus.specular_color);
    glUniform1f(loc_material_TXPS.specular_exponent, material_bus.specular_exponent);
    glUniform4fv(loc_material_TXPS.emissive_color, 1, material_bus.emissive_color);
}
void set_material_wolf(void) {
    // assume ShaderProgram_TXPS is used
    glUniform4fv(loc_material_TXPS.ambient_color, 1, material_wolf.ambient_color);
    glUniform4fv(loc_material_TXPS.diffuse_color, 1, material_wolf.diffuse_color);
    glUniform4fv(loc_material_TXPS.specular_color, 1, material_wolf.specular_color);
    glUniform1f(loc_material_TXPS.specular_exponent, material_wolf.specular_exponent);
    glUniform4fv(loc_material_TXPS.emissive_color, 1, material_wolf.emissive_color);
}
void set_material_floor(void) {
    // assume ShaderProgram_GS is used
    glUniform4fv(loc_material.ambient_color, 1, material_floor.ambient_color);
    glUniform4fv(loc_material.diffuse_color, 1, material_floor.diffuse_color);
    glUniform4fv(loc_material.specular_color, 1, material_floor.specular_color);
    glUniform1f(loc_material.specular_exponent, material_floor.specular_exponent);
    glUniform4fv(loc_material.emissive_color, 1, material_floor.emissive_color);
}

void set_material_dragon(int ambient, int diffuse, int specular) {

    if (ambient)
        glUniform3f(loc_Material_Ka, 0.4f, 0.3f, 0.1f);
    else
        glUniform3f(loc_Material_Ka, 0.0f, 0.0f, 0.0f);
    if (diffuse)
        glUniform3f(loc_Material_Kd, 051.0f/255.0f, 102.0f/255.0f, 204.0f/255.0f);
    else
        glUniform3f(loc_Material_Kd, 0.0f, 0.0f, 0.0f);
    if (specular) {
        glUniform3f(loc_Material_Ks, 0.628281f, 0.555802f, 0.555802f);
        glUniform1f(loc_Material_Shininess, 21.2f); // [0.0, 128.0]
    }
    else {
        glUniform3f(loc_Material_Ks, 0.0f, 0.0f, 0.0f);
        glUniform1f(loc_Material_Shininess, 1.0f); // [0.0, 128.0]
    }
}
void prepare_wolf(void) {
    int i, n_bytes_per_vertex, n_bytes_per_triangle, wolf_n_total_triangles = 0;
    char filename[512];

    n_bytes_per_vertex = 8 * sizeof(float); // 3 for vertex, 3 for normal, and 2 for texcoord
    n_bytes_per_triangle = 3 * n_bytes_per_vertex;

    for (i = 0; i < N_WOLF_FRAMES; i++) {
        sprintf(filename, "Data/dynamic_objects/wolf/wolf_%02d_vnt.geom", i);
        wolf_n_triangles[i] = read_geometry(&wolf_vertices[i], n_bytes_per_triangle, filename);
        // assume all geometry files are effective
        wolf_n_total_triangles += wolf_n_triangles[i];

        if (i == 0)
            wolf_vertex_offset[i] = 0;
        else
            wolf_vertex_offset[i] = wolf_vertex_offset[i - 1] + 3 * wolf_n_triangles[i - 1];
    }

    // initialize vertex buffer object
    glGenBuffers(1, &wolf_VBO);

    glBindBuffer(GL_ARRAY_BUFFER, wolf_VBO);
    glBufferData(GL_ARRAY_BUFFER, wolf_n_total_triangles * n_bytes_per_triangle, NULL, GL_STATIC_DRAW);

    for (i = 0; i < N_WOLF_FRAMES; i++)
        glBufferSubData(GL_ARRAY_BUFFER, wolf_vertex_offset[i] * n_bytes_per_vertex,
            wolf_n_triangles[i] * n_bytes_per_triangle, wolf_vertices[i]);

    // as the geometry data exists now in graphics memory, ...
    for (i = 0; i < N_WOLF_FRAMES; i++)
        free(wolf_vertices[i]);

    // initialize vertex array object
    glGenVertexArrays(1, &wolf_VAO);
    glBindVertexArray(wolf_VAO);

    glBindBuffer(GL_ARRAY_BUFFER, wolf_VBO);
    glVertexAttribPointer(LOC_VERTEX, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(LOC_NORMAL, 3, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(LOC_TEXCOORD, 2, GL_FLOAT, GL_FALSE, n_bytes_per_vertex, BUFFER_OFFSET(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    material_wolf.ambient_color[0] = 0.24725f;
    material_wolf.ambient_color[1] = 0.1995f;
    material_wolf.ambient_color[2] = 0.0745f;
    material_wolf.ambient_color[3] = 1.0f;

    material_wolf.diffuse_color[0] = 0.75164f;
    material_wolf.diffuse_color[1] = 0.60648f;
    material_wolf.diffuse_color[2] = 0.22648f;
    material_wolf.diffuse_color[3] = 1.0f;

    material_wolf.specular_color[0] = 0.728281f;
    material_wolf.specular_color[1] = 0.655802f;
    material_wolf.specular_color[2] = 0.466065f;
    material_wolf.specular_color[3] = 1.0f;

    material_wolf.specular_exponent = 51.2f;

    material_wolf.emissive_color[0] = 0.1f;
    material_wolf.emissive_color[1] = 0.1f;
    material_wolf.emissive_color[2] = 0.0f;
    material_wolf.emissive_color[3] = 1.0f;

    glHint(GL_GENERATE_MIPMAP_HINT, GL_NICEST);

    glActiveTexture(GL_TEXTURE0 + TEXTURE_ID_WOLF);
    glBindTexture(GL_TEXTURE_2D, texture_names[TEXTURE_ID_WOLF]);

   My_glTexImage2D_from_file("Data/wolfwolf.jpg");

    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);



}

void prepare_bike(void) {
    set_up_object(OBJECT_BIKE, "Data/static_objects/bike_vnt.geom", 8 * sizeof(float));
}

void prepare_ironman(void) {
    set_up_object(OBJECT_IRONMAN, "Data/static_objects/ironman_vnt.geom", 8 * sizeof(float));
}

void draw_tiger(void) {
   // glUniform3f(loc_primitive_color, 165.0f / 255.0f, 042.0f / 255.0f, 042.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(tiger_VAO);
    glDrawArrays(GL_TRIANGLES, tiger_vertex_offset[cur_frame_tiger], 3 * tiger_n_triangles[cur_frame_tiger]);
    glBindVertexArray(0);
}
void draw_ben(void) {
   // glUniform3f(loc_primitive_color, 100.0f / 255.0f, 149.0f / 255.0f, 237.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(ben_VAO);
    glDrawArrays(GL_TRIANGLES, ben_vertex_offset[cur_frame_ben], 3 * ben_n_triangles[cur_frame_ben]);
    glBindVertexArray(0);
}
void draw_wolf(void) {
   // glUniform3f(loc_primitive_color, 105.0f / 255.0f, 105.0f / 255.0f, 105.0f / 255.0f);
    glFrontFace(GL_CW);

    glBindVertexArray(wolf_VAO);
    glDrawArrays(GL_TRIANGLES, wolf_vertex_offset[cur_frame_wolf], 3 * wolf_n_triangles[cur_frame_wolf]);
    glBindVertexArray(0);
}
void draw_floor(void) {
    glFrontFace(GL_CW);
    glBindVertexArray(rectangle_VAO);
  //  glBindVertexArray(object_VAO[OBJECT_SQUARE16]);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);
}

void draw_spider(void) {
    glUniform3f(loc_primitive_color, 047.0f / 255.0f, 079.0f / 255.0f, 079.0f / 255.0f);
   
    glFrontFace(GL_CW);
   
    glBindVertexArray(spider_VAO);
    glDrawArrays(GL_TRIANGLES, spider_vertex_offset[cur_frame_spider], 3 * spider_n_triangles[cur_frame_spider]);
    glBindVertexArray(0);
}
void draw_object(int object_ID, float r, float g, float b) {
    glUniform3f(loc_primitive_color, r, g, b);
    glFrontFace(GL_CCW);
    glBindVertexArray(object_VAO[object_ID]);
    glDrawArrays(GL_TRIANGLES, 0, 3 * object_n_triangles[object_ID]);
    glBindVertexArray(0);
}
void draw_dragon(void) {
    glFrontFace(GL_CW);

    
    glBindVertexArray(object_VAO[OBJECT_DRAGON]);
    glDrawArrays(GL_TRIANGLES, 0, 3 * object_n_triangles[OBJECT_DRAGON]);
    glBindVertexArray(0);
}
void draw_bus(void) {
    glFrontFace(GL_CCW);

    glBindVertexArray(object_VAO[OBJECT_BUS]);
    glDrawArrays(GL_TRIANGLES, 0, 3 * object_n_triangles[OBJECT_BUS]);
    glBindVertexArray(0);
}
void initialize_lights_and_material(void) { // follow OpenGL conventions for initialization
    int i;

    glUseProgram(h_ShaderProgram_GS);
    
    glUniform4f(loc_global_ambient_color, 0.115f, 0.115f, 0.115f, 1.0f);
    for (i = 0; i <4; i++) {
        glUniform1i(loc_light[i].light_on, 0); // turn off all lights initially
        glUniform4f(loc_light[i].position, 0.0f, 0.0f, 1.0f, 0.0f);
        glUniform4f(loc_light[i].ambient_color, 0.0f, 0.0f, 0.0f, 1.0f);
        if (i == 0) {
            glUniform4f(loc_light[i].diffuse_color, 1.0f, 1.0f, 1.0f, 1.0f);
            glUniform4f(loc_light[i].specular_color, 1.0f, 1.0f, 1.0f, 1.0f);
        }
        else {
            glUniform4f(loc_light[i].diffuse_color, 0.0f, 0.0f, 0.0f, 1.0f);
            glUniform4f(loc_light[i].specular_color, 0.0f, 0.0f, 0.0f, 1.0f);
        }
        glUniform3f(loc_light[i].spot_direction, 0.0f, 0.0f, -1.0f);
        glUniform1f(loc_light[i].spot_exponent, 0.0f); // [0.0, 128.0]
        glUniform1f(loc_light[i].spot_cutoff_angle, 180.0f); // [0.0, 90.0] or 180.0 (180.0 for no spot light effect)
        glUniform4f(loc_light[i].light_attenuation_factors, 1.0f, 0.0f, 0.0f, 0.0f); // .w != 0.0f for no ligth attenuation
    }
    
    glUniform4f(loc_material.ambient_color, 0.1f, 0.1f, 0.1f, 1.0f);
    glUniform4f(loc_material.diffuse_color, 0.8f, 0.8f, 0.8f, 1.0f);
    glUniform4f(loc_material.specular_color, 0.0f, 0.0f, 0.0f, 1.0f);
    glUniform4f(loc_material.emissive_color, 0.0f, 0.0f, 0.0f, 1.0f);
    glUniform1f(loc_material.specular_exponent, 0.0f); // [0.0, 128.0]
    
    glUniform1i(loc_screen_effect, 0);
    glUniform1f(loc_screen_frequency, 1.0f);
    glUniform1f(loc_screen_width, 0.125f);

    glUniform1i(loc_blind_effect, 0);


    glUseProgram(0);
    
    glUseProgram(h_ShaderProgram_TXPS);

    glUniform4f(loc_global_ambient_color_TXPS, 0.115f, 0.115f, 0.115f, 1.0f);
    for (i = 0; i < 4; i++) {
       
        glUniform1i(loc_light_TXPS[i].light_on, 0); // turn off all lights initially
        glUniform4f(loc_light_TXPS[i].position, 0.0f, 0.0f, 1.0f, 0.0f);
        glUniform4f(loc_light_TXPS[i].ambient_color, 0.0f, 0.0f, 0.0f, 1.0f);
        if (i == 0) {
            glUniform4f(loc_light_TXPS[i].diffuse_color, 1.0f, 1.0f, 1.0f, 1.0f);
            glUniform4f(loc_light_TXPS[i].specular_color, 1.0f, 1.0f, 1.0f, 1.0f);
        }
        else {
            glUniform4f(loc_light_TXPS[i].diffuse_color, 0.0f, 0.0f, 0.0f, 1.0f);
            glUniform4f(loc_light_TXPS[i].specular_color, 0.0f, 0.0f, 0.0f, 1.0f);
        }
        glUniform3f(loc_light_TXPS[i].spot_direction, 0.0f, 0.0f, -1.0f);
        glUniform1f(loc_light_TXPS[i].spot_exponent, 0.0f); // [0.0, 128.0]
        glUniform1f(loc_light_TXPS[i].spot_cutoff_angle, 180.0f); // [0.0, 90.0] or 180.0 (180.0 for no spot light effect)
        glUniform4f(loc_light_TXPS[i].light_attenuation_factors, 1.0f, 0.0f, 0.0f, 0.0f); // .w != 0.0f for no ligth attenuation
    }

    glUniform4f(loc_material_TXPS.ambient_color, 0.2f, 0.2f, 0.2f, 1.0f);
    glUniform4f(loc_material_TXPS.diffuse_color, 0.8f, 0.8f, 0.8f, 1.0f);
    glUniform4f(loc_material_TXPS.specular_color, 0.0f, 0.0f, 0.0f, 1.0f);
    glUniform4f(loc_material_TXPS.emissive_color, 0.0f, 0.0f, 0.0f, 1.0f);
    glUniform1f(loc_material_TXPS.specular_exponent, 0.0f); // [0.0, 128.0]

    glUseProgram(0);


}

void initialize_flags(void) {
    flag_tiger_animation = 1;
    flag_polygon_fill = 1;
    flag_texture_mapping = 1;
   

    glUseProgram(h_ShaderProgram_TXPS);
 
    glUniform1i(loc_flag_texture_mapping, flag_texture_mapping);
    glUseProgram(0);
}


void set_up_scene_lights(void) {
    // point_light_EC: use light 0
    /*
    light[0].light_on = 1;
    light[0].position[0] = 10.0f; light[0].position[1] = 30.0f;    // point light position in EC
    light[0].position[2] = 10.0f; light[0].position[3] = 1.0f;

    light[0].ambient_color[0] = 0.01f; light[0].ambient_color[1] = 0.01f;
    light[0].ambient_color[2] = 0.01f; light[0].ambient_color[3] = 1.0f;

    light[0].diffuse_color[0] = 0.7f; light[0].diffuse_color[1] = 0.7f;
    light[0].diffuse_color[2] = 0.7f; light[0].diffuse_color[3] = 1.5f;

    light[0].specular_color[0] = 0.9f; light[0].specular_color[1] = 0.9f;
    light[0].specular_color[2] = 0.9f; light[0].specular_color[3] = 1.0f;
    */


    light[1].light_on = 1;
    light[1].position[0] = 13.0f; light[1].position[1] = 30.0f; // spot light position in WC
    light[1].position[2] = 13.0f; light[1].position[3] = 1.0f;

    light[1].ambient_color[0] = 0.1f; light[1].ambient_color[1] = 0.1f;
    light[1].ambient_color[2] = 0.1f; light[1].ambient_color[3] = 1.00f;

    light[1].diffuse_color[0] = 0.5f; light[1].diffuse_color[1] = 0.5f;
    light[1].diffuse_color[2] = 0.5f; light[1].diffuse_color[3] = 1.5f;

    light[1].specular_color[0] = 0.82f; light[1].specular_color[1] = 0.82f;
    light[1].specular_color[2] = 0.82f; light[1].specular_color[3] = 1.0f;

    light[1].spot_direction[0] = 0.0f; light[1].spot_direction[1] = -1.0f; // spot light direction in WC
    light[1].spot_direction[2] = 0.0f;
    light[1].spot_cutoff_angle = 45.8f;
    light[1].spot_exponent = 2.0f;




    light[2].light_on = 1;
    light[2].position[0] = 23.0f; light[2].position[1] = 15.0f; // spot light position in WC
    light[2].position[2] = 17.0f; light[2].position[3] = 1.0f;
    light[2].ambient_color[0] = 0.9f; light[2].ambient_color[1] = 0.1f;
    light[2].ambient_color[2] = 0.1f; light[2].ambient_color[3] = 1.0f;

    light[2].diffuse_color[0] = 1.0f; light[2].diffuse_color[1] = 0.0f;
    light[2].diffuse_color[2] = 1.0f; light[2].diffuse_color[3] = 1.0f;

    light[2].specular_color[0] = 0.9f; light[2].specular_color[1] = 0.1f;
    light[2].specular_color[2] = 0.1f; light[2].specular_color[3] = 1.0f;

   // light[2].spot_direction[0] = 9.5f; light[2].spot_direction[1] = 7.7f;
  //  light[2].spot_direction[2] = 7.2f; 
    
   
    light[2].spot_direction[0] = -(23.0f-9.5f); light[2].spot_direction[1] = -(15.0f-7.7f); // spot light direction in WC
    light[2].spot_direction[2] = -(17.0f-7.2f);
    light[2].spot_cutoff_angle = 1.9f;
    light[2].spot_exponent = 8.0f;


    light[3].light_on = 1;
    light[3].position[0] = 12.0f; light[3].position[1] = 20.0f;
    light[3].position[2] = 20.0f; light[3].position[3] = 1.0f;

    light[3].ambient_color[0] = 0.852f; light[3].ambient_color[1] = 0.152f;
    light[3].ambient_color[2] = 0.152f; light[3].ambient_color[3] = 1.0f;

    light[3].diffuse_color[0] = 0.0f; light[3].diffuse_color[1] = 0.0f;
    light[3].diffuse_color[2] = 0.8f; light[3].diffuse_color[3] = 1.0f;

    light[3].specular_color[0] = 0.772f; light[3].specular_color[1] = 0.172f;
    light[3].specular_color[2] = 0.172f; light[3].specular_color[3] = 1.0f;

    light[3].spot_direction[0] = -10.0f; light[3].spot_direction[1] = -7.0f; // spot light direction in WC
    light[3].spot_direction[2] = -10.0f;
    light[3].spot_cutoff_angle = 180.0f;
    light[3].spot_exponent = 5.0f;



    glUseProgram(h_ShaderProgram_GS);

    glUniform1i(loc_light[0].light_on, light[0].light_on);
    glUniform4fv(loc_light[0].position, 1, light[0].position);
    glUniform4fv(loc_light[0].ambient_color, 1, light[0].ambient_color);
    glUniform4fv(loc_light[0].diffuse_color, 1, light[0].diffuse_color);
    glUniform4fv(loc_light[0].specular_color, 1, light[0].specular_color);
    glUniform3fv(loc_light[0].spot_direction, 1, light[0].spot_direction);

    glUniform1i(loc_light[1].light_on, light[1].light_on);
    glUniform4fv(loc_light[1].position, 1, light[1].position);
    glUniform4fv(loc_light[1].ambient_color, 1, light[1].ambient_color);
    glUniform4fv(loc_light[1].diffuse_color, 1, light[1].diffuse_color);
    glUniform4fv(loc_light[1].specular_color, 1, light[1].specular_color);
    glUniform3fv(loc_light[1].spot_direction, 1, light[1].spot_direction);


   
   
    // need to supply position in EC for shading
    glm::vec4 position_EC2 = ViewMatrix * glm::vec4(light[1].position[0], light[1].position[1],
        light[1].position[1], light[1].position[3]);
    glUniform4fv(loc_light[1].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light[1].ambient_color, 1, light[1].ambient_color);
    glUniform4fv(loc_light[1].diffuse_color, 1, light[1].diffuse_color);
    glUniform4fv(loc_light[1].specular_color, 1, light[1].specular_color);
    // need to supply direction in EC for shading in this example shader
    // note that the viewing transform is a rigid body transform
    // thus transpose(inverse(mat3(ViewMatrix)) = mat3(ViewMatrix)
    glm::vec3 direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[1].spot_direction[0], light[1].spot_direction[1],
        light[1].spot_direction[2]);
    glUniform3fv(loc_light[1].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light[1].spot_cutoff_angle, light[1].spot_cutoff_angle);
    glUniform1f(loc_light[1].spot_exponent, light[1].spot_exponent);



    glUniform1i(loc_light[2].light_on, light[2].light_on);
    // need to supply position in EC for shading
    position_EC2 = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
        light[2].position[2], light[2].position[3]);
    glUniform4fv(loc_light[2].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
    glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
    glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);
    glUniform1i(loc_blind_effect, 0);
    // need to supply direction in EC for shading in this example shader
    // note that the viewing transform is a rigid body transform
    // thus transpose(inverse(mat3(ViewMatrix)) = mat3(ViewMatrix)
    direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
        light[2].spot_direction[2]);
    glUniform3fv(loc_light[2].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
    glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);




    glUniform1i(loc_light[3].light_on, light[3].light_on);
    //  glUniform1i(loc_light[2].blind_effect, light[2].blind_effect);

    position_EC2 = ViewMatrix * glm::vec4(light[3].position[0], light[3].position[1],
        light[3].position[2], light[3].position[3]);
    glUniform4fv(loc_light[3].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light[3].ambient_color, 1, light[3].ambient_color);
    glUniform4fv(loc_light[3].diffuse_color, 1, light[3].diffuse_color);
    glUniform4fv(loc_light[3].specular_color, 1, light[3].specular_color);

    direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[3].spot_direction[0], light[3].spot_direction[1],
        light[3].spot_direction[2]);
    glUniform3fv(loc_light[3].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light[3].spot_cutoff_angle, light[3].spot_cutoff_angle);
    glUniform1f(loc_light[3].spot_exponent, light[3].spot_exponent);



    glUseProgram(h_ShaderProgram_TXPS);
    glUniform1i(loc_light_TXPS[0].light_on, light[0].light_on);
    glUniform4fv(loc_light_TXPS[0].position, 1, light[0].position);
    glUniform4fv(loc_light_TXPS[0].ambient_color, 1, light[0].ambient_color);
    glUniform4fv(loc_light_TXPS[0].diffuse_color, 1, light[0].diffuse_color);
    glUniform4fv(loc_light_TXPS[0].specular_color, 1, light[0].specular_color);

    glUniform1i(loc_light_TXPS[1].light_on, light[1].light_on);
    // need to supply position in EC for shading
 //   glm::vec4 position_EC2 = ViewMatrix * glm::vec4(light[1].position[0], light[1].position[1],
 //       light[1].position[2], light[1].position[3]);
 //   glUniform4fv(loc_light_TXPS[1].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light_TXPS[1].ambient_color, 1, light[1].ambient_color);
    glUniform4fv(loc_light_TXPS[1].diffuse_color, 1, light[1].diffuse_color);
    glUniform4fv(loc_light_TXPS[1].specular_color, 1, light[1].specular_color);
    glUniform4fv(loc_light_TXPS[2].ambient_color, 1, light[2].ambient_color);
    glUniform4fv(loc_light_TXPS[2].diffuse_color, 1, light[2].diffuse_color);
    glUniform4fv(loc_light_TXPS[2].specular_color, 1, light[2].specular_color);
    glUniform4fv(loc_light_TXPS[3].ambient_color, 1, light[3].ambient_color);
    glUniform4fv(loc_light_TXPS[3].diffuse_color, 1, light[3].diffuse_color);
    glUniform4fv(loc_light_TXPS[3].specular_color, 1, light[3].specular_color);
    // need to supply direction in EC for shading in this example shader
    // note that the viewing transform is a rigid body transform
    // thus transpose(inverse(mat3(ViewMatrix)) = mat3(ViewMatrix)
  //  glm::vec3 direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[1].spot_direction[0], light[1].spot_direction[1],
   //     light[1].spot_direction[2]);
    //glUniform3fv(loc_light_TXPS[1].spot_direction, 1, &direction_EC2[0]);
   // glUniform1f(loc_light_TXPS[1].spot_cutoff_angle, light[1].spot_cutoff_angle);
    //glUniform1f(loc_light_TXPS[1].spot_exponent, light[1].spot_exponent);

    glUniform1i(loc_light_TXPS[0].light_on, light[0].light_on);
    glUniform4fv(loc_light_TXPS[0].position, 1, light[0].position);
    glUniform4fv(loc_light_TXPS[0].ambient_color, 1, light[0].ambient_color);
    glUniform4fv(loc_light_TXPS[0].diffuse_color, 1, light[0].diffuse_color);
    glUniform4fv(loc_light_TXPS[0].specular_color, 1, light[0].specular_color);
    glUniform3fv(loc_light_TXPS[0].spot_direction, 1, light[0].spot_direction);

    glUniform1i(loc_light_TXPS[1].light_on, light[1].light_on);
    glUniform4fv(loc_light_TXPS[1].position, 1, light[1].position);
    glUniform4fv(loc_light_TXPS[1].ambient_color, 1, light[1].ambient_color);
    glUniform4fv(loc_light_TXPS[1].diffuse_color, 1, light[1].diffuse_color);
    glUniform4fv(loc_light_TXPS[1].specular_color, 1, light[1].specular_color);
    glUniform3fv(loc_light_TXPS[1].spot_direction, 1, light[1].spot_direction);




    // need to supply position in EC for shading
    position_EC2 = ViewMatrix * glm::vec4(light[1].position[0], light[1].position[1],
        light[1].position[1], light[1].position[3]);
    glUniform4fv(loc_light_TXPS[1].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light_TXPS[1].ambient_color, 1, light[1].ambient_color);
    glUniform4fv(loc_light_TXPS[1].diffuse_color, 1, light[1].diffuse_color);
    glUniform4fv(loc_light_TXPS[1].specular_color, 1, light[1].specular_color);
    // need to supply direction in EC for shading in this example shader
    // note that the viewing transform is a rigid body transform
    // thus transpose(inverse(mat3(ViewMatrix)) = mat3(ViewMatrix)
    direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[1].spot_direction[0], light[1].spot_direction[1],
        light[1].spot_direction[2]);
    glUniform3fv(loc_light_TXPS[1].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light_TXPS[1].spot_cutoff_angle, light[1].spot_cutoff_angle);
    glUniform1f(loc_light_TXPS[1].spot_exponent, light[1].spot_exponent);



    glUniform1i(loc_light[2].light_on, light[2].light_on);
    // need to supply position in EC for shading
    position_EC2 = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
        light[2].position[2], light[2].position[3]);
    glUniform4fv(loc_light_TXPS[2].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light_TXPS[2].ambient_color, 1, light[2].ambient_color);
    glUniform4fv(loc_light_TXPS[2].diffuse_color, 1, light[2].diffuse_color);
    glUniform4fv(loc_light_TXPS[2].specular_color, 1, light[2].specular_color);
    glUniform1i(loc_blind_effect, 0);
    // need to supply direction in EC for shading in this example shader
    // note that the viewing transform is a rigid body transform
    // thus transpose(inverse(mat3(ViewMatrix)) = mat3(ViewMatrix)
    direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
        light[2].spot_direction[2]);
    glUniform3fv(loc_light_TXPS[2].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light_TXPS[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
    glUniform1f(loc_light_TXPS[2].spot_exponent, light[2].spot_exponent);




    glUniform1i(loc_light_TXPS[3].light_on, light[3].light_on);
    //  glUniform1i(loc_light[2].blind_effect, light[2].blind_effect);

    position_EC2 = ViewMatrix * glm::vec4(light[3].position[0], light[3].position[1],
        light[3].position[2], light[3].position[3]);
    glUniform4fv(loc_light_TXPS[3].position, 1, &position_EC2[0]);
    glUniform4fv(loc_light_TXPS[3].ambient_color, 1, light[3].ambient_color);
    glUniform4fv(loc_light_TXPS[3].diffuse_color, 1, light[3].diffuse_color);
    glUniform4fv(loc_light_TXPS[3].specular_color, 1, light[3].specular_color);

    direction_EC2 = glm::mat3(ViewMatrix) * glm::vec3(light[3].spot_direction[0], light[3].spot_direction[1],
        light[3].spot_direction[2]);
    glUniform3fv(loc_light_TXPS[3].spot_direction, 1, &direction_EC2[0]);
    glUniform1f(loc_light_TXPS[3].spot_cutoff_angle, light[3].spot_cutoff_angle);
    glUniform1f(loc_light_TXPS[3].spot_exponent, light[3].spot_exponent);




}

// End of geometry setup

// Begin of Callback function definitions
#define TO_RADIAN 0.01745329252f  
#define TO_DEGREE 57.295779513f

// include glm/*.hpp only if necessary
// #include <glm/glm.hpp> 
 //translate, rotate, scale, lookAt, perspective, etc.
// ViewProjectionMatrix = ProjectionMatrix * ViewMatrix
glm::vec3 lookat_u;
glm::vec3 lookat_v;
glm::vec3 lookat_n;
glm::vec3 VRP;
glm::vec3 VUP;
glm::vec3 PRP;
glm::vec3 VPN;
glm::mat4 Projection2;
glm::mat3 RotateM;
glm::vec3 light_pos;
glm::vec3 light_dir;
float angle_u = 0.0f;
float angle_v = 0.0f;
float angle_n = 0.0f;
float camX;
float camY;
float camZ;
int flag_a = 0;
typedef struct _Camera {
    glm::vec3 pos;
    glm::vec3 uaxis, vaxis, naxis;

    float fovy, aspect_ratio, near_c, far_c;
    int move;
} Camera;
Camera camera_wv;
Camera moveCam;
enum _CameraType { CAMERA_WORLD_VIEWER, CAMERA_DRIVER } camera_type;

float fovy=15.0f;
float aspect;
float zNear=5.0f;
float zFar=100.0f;
float iron_clock;
float bike_clock;
float godzilla_clock;
float tiger_clock;
float rotation_angle_tiger = 0.0f, rotation_angle_cow = 0.0f;
float rotation_angle_iron;
int flag_fill_floor = 0;
int sky_flag = 0;
int zoom_flag = 0;
int flag_n = 0;
int flag_v = 0;
int flag_u = 0;
glm::vec4 position_D;
glm::vec3 direction_D;
void display(void) {
  //  glClearColor(051.0f / 255.0f, 051.0f / 255.0f, 051.0f / 225.0f, 1.0f);
   // glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_LIGHTING);
   
    glUseProgram(h_ShaderProgram_GS);

    position_D = ViewMatrix * glm::vec4(light[1].position[0], light[1].position[1],
        light[1].position[2], light[1].position[3]);
    glUniform4fv(loc_light[1].position, 1, &position_D[0]);
    direction_D = glm::mat3(ViewMatrix) * glm::vec3(light[1].spot_direction[0], light[1].spot_direction[1],
        light[1].spot_direction[2]);
    glUniform3fv(loc_light[1].spot_direction, 1, &direction_D[0]);
    
    position_D = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
        light[2].position[2], light[2].position[3]);
    glUniform4fv(loc_light[2].position, 1, &position_D[0]);
    direction_D = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
        light[2].spot_direction[2]);
    glUniform3fv(loc_light[2].spot_direction, 1, &direction_D[0]);
    /*
    position_D = ViewMatrix * glm::vec4(light[3].position[0], light[3].position[1],
        light[3].position[2], light[3].position[3]);
    glUniform4fv(loc_light[3].position, 1, &position_D[0]);
    direction_D = glm::mat3(ViewMatrix) * glm::vec3(light[3].spot_direction[0], light[3].spot_direction[1],
        light[3].spot_direction[2]);
    glUniform3fv(loc_light[3].spot_direction, 1, &direction_D[0]);

    */
    glUseProgram(h_ShaderProgram);
    if (sky_flag == 1) {
        glClearColor(51.0f / 255.0f, 051.0f / 255.0f, 051.0f / 225.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
    else {
        glClearColor(204 / 255.0f, 204 / 255.0f, 204 / 255.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix, glm::vec3(9.5f, 7.7f, 7.2f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.0f, 1.0f, 1.0f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    draw_axes();
    glLineWidth(1.0f);
    glUseProgram(0);

    glUseProgram(h_ShaderProgram_GS);
 
    
    set_material_floor();
 //   ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix, glm::vec3(9.5f, 7.7f, 7.2f));
  //  ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(500.5f, 500.5f, 500.5f));
 //   ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix,
  //      90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
 //   ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));
  //  glUniformMatrix4fv(loc_ModelViewProjectionMatrix_GS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    ModelViewMatrix = glm::translate(ViewMatrix, glm::vec3(9.5f, 7.7f, 7.2f));
      ModelViewMatrix = glm::scale(ModelViewMatrix, glm::vec3(-50.5f, 50.5f, 50.5f));
     
     ModelViewMatrix = glm::rotate(ModelViewMatrix,
         180.0f * TO_RADIAN, glm::vec3(0.0f, 0.0f, 1.0f));
     ModelViewMatrix = glm::rotate(ModelViewMatrix,
         90.0f * TO_RADIAN, glm::vec3(1.0f, 0.0f, 0.0f));
    
     
    
     ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
      ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));
      
 //   glLineWidth(3.0f);
    //  draw_axes();
 //   glLineWidth(1.0f);
  //  if (flag_fill_floor == 1)
   //     glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix_GS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glUniformMatrix4fv(loc_ModelViewMatrix_GS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
    glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_GS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);

    //draw_object(OBJECT_SQUARE16, 255.0f / 255.0f, 218.0f / 255.0f, 185.0f / 225.0f); // Light Sky Blue
    draw_floor();
   // glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    
    glUseProgram(h_ShaderProgram);
   
    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(10.10f, 8.5f, 5.1f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 150.0f * TO_RADIAN,
        glm::vec3(0.0f, 0.0f, 1.0f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -20.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 30.0f * TO_RADIAN,
        glm::vec3(1.0f, 0.0f, 0.0f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.5f, 1.5f, 1.5f));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_COW, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // Ȳ���ڸ� - ����

    glUseProgram(h_ShaderProgram_PS);
    set_material_dragon(1, 1, 1);
  //  ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
   //     glm::vec3(11.5f, 7.7f, 8.6f));
   // ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.03f, 0.03f, 0.03f));
   // ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
    //    glm::vec3(1.0f, 0.0f, 0.0f));
   // glUniformMatrix4fv(loc_ModelViewProjectionMatrix_PS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
   // glLineWidth(3.0f);
    //glLineWidth(1.0f);
    ModelViewMatrix = glm::translate(ViewMatrix,
        glm::vec3(11.5f, 7.7f, 8.6f));
    ModelViewMatrix = glm::scale(ModelViewMatrix, glm::vec3(0.03f, 0.03f, 0.03f));
    ModelViewMatrix = glm::rotate(ModelViewMatrix, -90.0f * TO_RADIAN,
        glm::vec3(1.0f, 0.0f, 0.0f));
    ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
    ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix_PS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glUniformMatrix4fv(loc_ModelViewMatrix_PS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
    glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_PS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);

   // glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
   // draw_object(OBJECT_DRAGON, 102 / 255.0f, 51 / 255.0f, 153 / 255.0f); // ��� �߽� - ����
    draw_dragon();

    glUseProgram(0);

    glUseProgram(h_ShaderProgram);
    
    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(9.10f, 8.2f, 9.1f));
    ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 200.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));

    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.008f, 0.008f, -0.008f));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_GODZILLA, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // GODZILLA ���ڸ� - ����


    ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
        glm::vec3(9.10f, 8.9f, 7.1f));
    ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.3f, 0.3f, 0.3f));

    glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glLineWidth(3.0f);
    glLineWidth(1.0f);
    draw_object(OBJECT_IRONMAN, 204 / 255.0f, 204 / 255.0f, 204 / 255.0f); // �ֵ����ڸ� - ����


    glUseProgram(h_ShaderProgram_TXPS);
    set_material_bus();
    glUniform1i(loc_texture, TEXTURE_ID_BUS);
    
    ModelViewMatrix = glm::translate(ViewMatrix,
        glm::vec3(10.10f, 7.7f, 10.1f));
    ModelViewMatrix = glm::rotate(ModelViewMatrix, 30.0f * TO_RADIAN,
        glm::vec3(0.0f, 1.0f, 0.0f));
    ModelViewMatrix = glm::scale(ModelViewMatrix, glm::vec3(0.05f, 0.05f, 0.05f));
    ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
    ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));
    glUniformMatrix4fv(loc_ModelViewProjectionMatrix_TXPS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
    glUniformMatrix4fv(loc_ModelViewMatrix_TXPS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
    glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_TXPS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);
   
    
    draw_bus(); // ���� - ����
    glUseProgram(0);


    glUseProgram(h_ShaderProgram_GS);
    set_material_tiger();
    
    if (TIGER_FLAG == 1) {

    }
    else {
        tiger_clock++;
        if (tiger_clock == 360) {
            tiger_clock = 0;
        }
    }

        ModelViewMatrix = glm::translate(ViewMatrix,
            glm::vec3(11.5f, 7.7f, 8.6f));
        ModelViewMatrix = glm::rotate(ModelViewMatrix,
            -tiger_clock * TO_RADIAN * 10, glm::vec3(0.0f, 1.0f, 0.0f));

        ModelViewMatrix = glm::rotate(ModelViewMatrix, -90.0f * TO_RADIAN,
            glm::vec3(0.0f, 1.0f, 0.0f));
        ModelViewMatrix = glm::rotate(ModelViewMatrix, -90.0f * TO_RADIAN,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewMatrix = glm::translate(ModelViewMatrix,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewMatrix = glm::scale(ModelViewMatrix, glm::vec3(0.006f, 0.006f, 0.006f));
        ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
        ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix_GS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glUniformMatrix4fv(loc_ModelViewMatrix_GS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
        glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_GS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);
        glLineWidth(3.0f);
        glLineWidth(1.0f);
        
   
        draw_tiger();
        glUseProgram(h_ShaderProgram);
        //ȣ���̱׸��� - ������ü
    
       

        glUseProgram(h_ShaderProgram_GS);
        set_material_ben();
     
        
        ModelViewMatrix = glm::translate(ViewMatrix,
            glm::vec3(9.5f, 7.7f, 7.8f));
       
        if (IRON_FLAG == 1) {

        }
        else {
            iron_clock++;
            if (iron_clock == 30) {
                iron_clock = 0;
            }
        }
        if (iron_clock <= 15) {
            ModelViewMatrix = glm::translate(ModelViewMatrix, glm::vec3((float)(iron_clock * 2) * 0.1, sinf(iron_clock * 24 * TO_RADIAN), 0.0f));
        }
        else {
            ModelViewMatrix = glm::translate(ModelViewMatrix, glm::vec3(6 - (float)(iron_clock * 2) * 0.1 - 0.2, sinf(iron_clock * 24 * TO_RADIAN), 0.0f));
        }
        ModelViewMatrix = glm::rotate(ModelViewMatrix, 180.0f * TO_RADIAN,
            glm::vec3(0.0f, 0.0f, 1.0f));
        ModelViewMatrix = glm::scale(ModelViewMatrix, glm::vec3(-1.1f, 1.1f, 1.1f));
       // glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
      //  light[3].position[0] = 12.0f;
      //  light[3].position[1] = 15.0f;
      //  light[3].position[2] = 20.f;
       // light[3].spot_direction[0] = 10.0f;
        //light[3].spot_direction[1] = 7.0f;
       // light[3].spot_direction[2] = 10.f;
        position_D = ModelViewMatrix * glm::vec4(light[3].position[0], light[3].position[1], light[3].position[2], light[3].position[3]);
        glUniform4fv(loc_light[3].position, 1, &position_D[0]);
        direction_D = glm::mat3(ModelViewMatrix) * glm::vec3(light[3].spot_direction[0], light[3].spot_direction[1],
            light[3].spot_direction[2]);
        glUniform3fv(loc_light[3].spot_direction, 1, &direction_D[0]);

        ModelViewProjectionMatrix = ProjectionMatrix * ModelViewMatrix;
        ModelViewMatrixInvTrans = glm::inverseTranspose(glm::mat3(ModelViewMatrix));
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix_GS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glUniformMatrix4fv(loc_ModelViewMatrix_GS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
        glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_GS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);
        

    

        draw_ben();

        
        glUseProgram(h_ShaderProgram);
        //ben- ������ ��ü
    
        if (BIKE_FLAG == 1) {

        }
        else {
            bike_clock++;
            if (bike_clock == 360) {
                bike_clock = 0;
            }
        }
        
        
        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(11.5f, 7.7f, 9.6f));
        //bike_clock = bike_clock * 3;
        if (bike_clock <= 60) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f, 9.6f - 0.03 * bike_clock));
        }
        else if (bike_clock <= 120) {

            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f + (bike_clock - 60) * 0.03, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (bike_clock <= 180) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(13.5f - bike_clock * 0.01, 8.5f, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));

        }
        else if (bike_clock <= 240) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.9f, 9.2f - (bike_clock - 180) * 0.02, 7.2f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (bike_clock <= 300) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.9f, 7.7f, 6.8f + 0.03 * (bike_clock - 240)));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }

        else {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f + 0.02 * (bike_clock - 300), 7.7f, 8.5f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 1.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, -90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(0.0f, 0.0f, 1.0f));
            ModelViewProjectionMatrix = glm::rotate(ModelViewProjectionMatrix, 90.0f * TO_RADIAN,
                glm::vec3(1.0f, 0.0f, 0.0f));
        }
        ModelViewProjectionMatrix = glm::translate(ModelViewProjectionMatrix,
            glm::vec3(1.0f, 0.0f, 0.0f));
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(0.2f, -0.2f, -0.2f));
       
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glLineWidth(3.0f);
        glLineWidth(1.0f);
       
        draw_spider();
     
        //spider�׸��� - ������ü
    
        glUseProgram(h_ShaderProgram_TXPS);
        set_material_wolf();
        glUniform1i(loc_texture, TEXTURE_ID_WOLF);
        ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
            glm::vec3(9.5f, 7.7f, 7.8f));
      
        if (GODZILLA_FLAG == 1) {
           
        }
        else {
            godzilla_clock++;
            if (godzilla_clock == 30) {
                godzilla_clock = 0;
            }
        }
      
        if (godzilla_clock <= 15) {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 7.7f + godzilla_clock * 0.1, 10.5f));
        }
        else {
            ModelViewProjectionMatrix = glm::translate(ViewProjectionMatrix,
                glm::vec3(11.5f, 9.2f - (godzilla_clock - 15) * 0.1, 10.5f));
        }
        
        ModelViewProjectionMatrix = glm::scale(ModelViewProjectionMatrix, glm::vec3(1.01f, 1.01f, 1.01f));
        glUniformMatrix4fv(loc_ModelViewProjectionMatrix_TXPS, 1, GL_FALSE, &ModelViewProjectionMatrix[0][0]);
        glUniformMatrix4fv(loc_ModelViewMatrix_TXPS, 1, GL_FALSE, &ModelViewMatrix[0][0]);
        glUniformMatrix3fv(loc_ModelViewMatrixInvTrans_TXPS, 1, GL_FALSE, &ModelViewMatrixInvTrans[0][0]);

        

        glLineWidth(3.0f);
        glLineWidth(1.0f);
        draw_wolf();
     
        //wolf - ������ ��ü

        glUseProgram(0);



    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y) {
    glm::vec4 position;
    glm::vec3 direction;
    static int flag_blind_effect = 0;
    if ((key == 'w')) {
       

        glUseProgram(h_ShaderProgram_GS);
        light[1].light_on = 1 - light[1].light_on;
        printf("%2.f\n",light[1].position[0]);
        printf("aa");
        glUniform1i(loc_light[1].light_on, light[1].light_on);
        glUseProgram(0);

        glutPostRedisplay();
        return;
    }

    if ((key == 'e')) {
        glUseProgram(h_ShaderProgram_TXPS);
        light[2].light_on = 1 - light[2].light_on;
        glUniform1i(loc_light_TXPS[2].light_on, light[2].light_on);

        glUseProgram(h_ShaderProgram_GS);
        
        printf("%2.f\n", light[2].position[0]);
        printf("aa");
        glUniform1i(loc_light[2].light_on, light[2].light_on);
        glUseProgram(0);

        glutPostRedisplay();
        return;
    }
    if ((key == 'm')) {


        glUseProgram(h_ShaderProgram_GS);
        light[3].light_on = 1 - light[3].light_on;
        printf("%2.f\n", light[3].position[0]);
        printf("aa");
        glUniform1i(loc_light[3].light_on, light[3].light_on);
        glUseProgram(0);

        glutPostRedisplay();
        return;
    }

    switch (key) {
    case 27: // ESC key
        glutLeaveMainLoop(); // Incur destuction callback for cleanups.
        break;
     
 
    case 'f':
  
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        glutReshapeFunc(reshape);
        if (flag_n==0 &&flag_v==0&&flag_n==0) {
            PRP = glm::vec3(23.0f, 15.0f, 17.0f);
            VRP = glm::vec3(9.5f, 7.7f, 7.2f);
            VUP = glm::vec3(0.0f, 1.0f, 0.0f);
            flag_f = 1;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
        }
        
        
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
       /*
        
        glUseProgram(h_ShaderProgram_GS);
        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);
        
        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -VPN.x; light[2].spot_direction[1] = -VPN.y; // spot light direction in WC
        light[2].spot_direction[2] = -VPN.z;
        light[2].spot_cutoff_angle = 40.0f;
        light[2].spot_exponent = 8.0f;


       
      //  glUniform1i(loc_light[2].blind_effect, light[2].blind_effect);

        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);

        */

        /*
        position[0] = PRP.x;
        position[1] = PRP.y;
        position[2] = PRP.z;
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        //     direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0],
          //       light[2].spot_direction[1], light[2].spot_direction[2]);
        direction[0] = VRP.x;
        direction[1] = VRP.y;
        direction[2] = VRP.z;
       
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);

        glUniform1i(loc_light[2].light_on, light[2].light_on);
        // need to supply position in EC for shading

        position = ViewMatrix * glm::vec4(PRP.x, PRP.y, PRP.z, 1.0f);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);
        // need to supply direction in EC for shading in this example shader
        direction = glm::mat3(ViewMatrix) * VRP;
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        */

        glUseProgram(0);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

        
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
     
        break;
        
    case 'a':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(20.0f, 7.7f, 15.0f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 1.0f, 0.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
       
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 1;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
        
    case '7':
        if (flag_a == 1) {
            camera1_left += 0.3f;

           
            VRP = VRP - camera1_left * lookat_u;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
            
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 1;
            flag_8 = 0;
            flag_9 = 0;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '8':
        if (flag_a == 1) {
            camera1_right += 0.3f;

       
            VRP = VRP + camera1_right * lookat_u;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
          
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 1;
            flag_9 = 0;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '9':
        if (flag_a == 1) {
            camera1_up += 0.3f;

           
            VRP = VRP + camera1_up * lookat_v;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
           
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 0;
            flag_9 = 1;
            flag_0 = 0;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case '0':
        if (flag_a == 1) {
            camera1_down += 0.3f;

            VRP = VRP - camera1_down * lookat_v;
            VPN = PRP - VRP;
            lookat_n = glm::normalize(VPN);
            lookat_u = glm::normalize(glm::cross(VUP, VPN));
            lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
           
            ViewMatrix = glm::lookAt(PRP, VRP, VUP);
            ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
            glutPostRedisplay();
            flag_7 = 0;
            flag_8 = 0;
            flag_9 = 0;
            flag_0 = 1;
            flag_n = 0;
            flag_v = 0;
            flag_u = 0;
        }
        break;
    case 'b':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
    
        PRP = glm::vec3(15.0f, 7.2f, 13.0f);
        VRP = glm::vec3(5.5f, 9.7f, 5.2f);
        VUP = glm::vec3(0.0f, 1.0f, 0.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
      
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
    
    case 'c':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(9.5f, 50.7f, 7.2f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 0.0f, 1.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
        
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
    
    case 'd':
        if (zoom_flag == 1) {
            ProjectionMatrix = Projection2;
            zoom_flag = 0;
        }
        PRP = glm::vec3(9.5f, -10.7f, 7.2f);
        VRP = glm::vec3(9.5f, 7.7f, 7.2f);
        VUP = glm::vec3(0.0f, 0.0f, 1.0f);
        VPN = PRP - VRP;
        lookat_n = glm::normalize(VPN);
        lookat_u = glm::normalize(glm::cross(VUP, VPN));
        lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
       
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glutPostRedisplay();
        flag_a = 0;
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 0;
        break;
   
        
    case 't':
        sky_flag = 1 - sky_flag;
        break;
    case 'n':
    
        //angle_n = angle_n + 0.1f;
        angle_n = 0.5f;
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_n* TO_RADIAN, lookat_n));
        lookat_u = RotateM * lookat_u;
        lookat_v = RotateM * lookat_v;
        VUP = RotateM * VUP;
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        VRP = PRP - lookat_n;
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(lookat_n).x; light[2].spot_direction[1] = -(lookat_n).y; // spot light direction in WC
        light[2].spot_direction[2] = -(lookat_n).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 1;
        flag_v = 0;
        flag_u = 0;
        break;


    
    case 'u':
      
        //angle_u = angle_u + 0.1f;
        angle_u = 0.5f;
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_u * TO_RADIAN, lookat_u));
        lookat_v = RotateM * lookat_v;
        lookat_n = RotateM * lookat_n;
        VUP = RotateM * VUP;
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        VRP = PRP - lookat_n;

        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(lookat_n).x; light[2].spot_direction[1] = -(lookat_n).y; // spot light direction in WC
        light[2].spot_direction[2] = -(lookat_n).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 0;
        flag_u = 1;
        break;
        
    case 'v':
        angle_v = 0.5f;
       // angle_v = angle_v + 0.1f;
        RotateM = glm::mat3(glm::rotate(glm::mat4(1.0f), angle_v*TO_RADIAN, lookat_v));
        lookat_u = RotateM * lookat_u;
        lookat_n = RotateM * lookat_n;
        
        ViewMatrix = glm::mat4(lookat_u.x, lookat_v.x, lookat_n.x, 0.0f,
            lookat_u.y, lookat_v.y, lookat_n.y, 0.0f,
            lookat_u.z, lookat_v.z, lookat_n.z, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f);
        ViewMatrix = glm::translate(ViewMatrix, -PRP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        VRP = PRP-lookat_n;
        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(lookat_n).x; light[2].spot_direction[1] = -(lookat_n).y; // spot light direction in WC
        light[2].spot_direction[2] = -(lookat_n).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        flag_7 = 0;
        flag_8 = 0;
        flag_9 = 0;
        flag_0 = 0;
        flag_n = 0;
        flag_v = 1;
        flag_u = 0;
        break;
        

        
    case 'i':
      
        PRP = PRP + 1.0f * lookat_v;
        VRP = VRP + 1.0f * lookat_v;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(PRP - VRP).x; light[2].spot_direction[1] = -(PRP - VRP).y; // spot light direction in WC
        light[2].spot_direction[2] = -(PRP - VRP).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);


        glUseProgram(h_ShaderProgram_TXPS);

        light[2].light_on = 1;
        glUniform1i(loc_light_TXPS[2].light_on, light[2].light_on);


        glUniform4fv(loc_light_TXPS[2].position, 1, &position[0]);
        glUniform4fv(loc_light_TXPS[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light_TXPS[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light_TXPS[2].specular_color, 1, light[2].specular_color);

        
        glUniform3fv(loc_light_TXPS[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light_TXPS[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light_TXPS[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);

        break;
    case 'j':
        
        PRP = PRP - 1.0f * lookat_u;
        VRP = VRP - 1.0f * lookat_u;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        
        glUseProgram(h_ShaderProgram_GS);
   
        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);
        
        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(PRP-VRP).x; light[2].spot_direction[1] = -(PRP - VRP).y; // spot light direction in WC
        light[2].spot_direction[2] = -(PRP - VRP).z;
        


        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        
        
        break;

    case 'l':
       
        PRP = PRP + 1.0f * lookat_u;
        VRP = VRP + 1.0f * lookat_u;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(PRP - VRP).x; light[2].spot_direction[1] = -(PRP - VRP).y; // spot light direction in WC
        light[2].spot_direction[2] = -(PRP - VRP).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        break;
    case 'k':
       
        PRP = PRP - 1.0f * lookat_v;
        VRP = VRP - 1.0f * lookat_v;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        glUseProgram(h_ShaderProgram_GS);

        light[2].light_on = 1;
        glUniform1i(loc_light[2].light_on, light[2].light_on);

        light[2].position[0] = PRP.x; light[2].position[1] = PRP.y; // spot light position in WC
        light[2].position[2] = PRP.z; light[2].position[3] = 1.0f;
        light[2].spot_direction[0] = -(PRP - VRP).x; light[2].spot_direction[1] = -(PRP - VRP).y; // spot light direction in WC
        light[2].spot_direction[2] = -(PRP - VRP).z;



        position = ViewMatrix * glm::vec4(light[2].position[0], light[2].position[1],
            light[2].position[2], light[2].position[3]);
        glUniform4fv(loc_light[2].position, 1, &position[0]);
        glUniform4fv(loc_light[2].ambient_color, 1, light[2].ambient_color);
        glUniform4fv(loc_light[2].diffuse_color, 1, light[2].diffuse_color);
        glUniform4fv(loc_light[2].specular_color, 1, light[2].specular_color);

        direction = glm::mat3(ViewMatrix) * glm::vec3(light[2].spot_direction[0], light[2].spot_direction[1],
            light[2].spot_direction[2]);
        glUniform3fv(loc_light[2].spot_direction, 1, &direction[0]);
        glUniform1f(loc_light[2].spot_cutoff_angle, light[2].spot_cutoff_angle);
        glUniform1f(loc_light[2].spot_exponent, light[2].spot_exponent);
        glUseProgram(0);
        break;
    case 'o':
      
        PRP = PRP - 1.0f * lookat_n;
        VRP = VRP - 1.0f * lookat_n;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;

    case 'p':
      
        PRP = PRP + 1.0f * lookat_n;
        VRP = VRP + 1.0f * lookat_n;
        ViewMatrix = glm::lookAt(PRP, VRP, VUP);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    case 'q':
        //zoom in
        zoom_flag = 1;
       
        zFar = zFar + 2;
        fovy = fovy - 2;
        if (fovy < 2) {
            fovy = 2;
        }
        ProjectionMatrix = glm::perspective(fovy*TO_RADIAN, aspect,zNear, zFar);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;

    case 'x':
        //zoom out
        zFar = zFar - 2;
       
        fovy = fovy + 2;
        if (fovy > 180) {
            fovy = 178;
        }
        ProjectionMatrix = glm::perspective(fovy * TO_RADIAN, aspect, zNear, zFar);
        ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
        break;
    
    case '1':
        if (TIGER_FLAG == 1) {
            TIGER_FLAG = 0;
        }
        else {
            TIGER_FLAG = 1;
        }
        break;
    case '2':
        printf("2");
        if (GODZILLA_FLAG == 1) {
            GODZILLA_FLAG = 0;
        }
        else {
            GODZILLA_FLAG = 1;
        }
        break;
    case '3':
        if (BIKE_FLAG == 1) {
            BIKE_FLAG = 0;
        }
        else {
            BIKE_FLAG = 1;
        }
        break;
    case '4':
        if (IRON_FLAG == 1) {
            IRON_FLAG = 0;
        }
        else {
            IRON_FLAG = 1;
        }
        break;
    case 'y':
        flag_blind_effect = 1 - flag_blind_effect;
        glUseProgram(h_ShaderProgram_GS);
        glUniform1i(loc_blind_effect, flag_blind_effect);
        glUseProgram(0);
        glutPostRedisplay();
        break;
    }
   


}
int prevx, prevy;



void mousepress(int button, int state, int x, int y) {
 
    if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN)) {
        flag_fill_floor = 1;
        glutPostRedisplay();
    }
    else if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_UP)) {
        flag_fill_floor = 0;
        glutPostRedisplay();
    }
   
}

void reshape(int width, int height) {
    float aspect_ratio;
    glViewport(0, 0, width, height);
    
    aspect_ratio = (float)width / height;
    aspect = aspect_ratio;
    ProjectionMatrix = glm::perspective(15.0f * TO_RADIAN, aspect_ratio, 1.0f, 1000.0f);
    Projection2 = ProjectionMatrix;
    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;
    glutPostRedisplay();
}

void timer_scene(int timestamp_scene) {
  
   
    rotation_angle_tiger = (float)(timestamp_scene % 360);
    rotation_angle_cow = (float)(timestamp_scene % 181);
    cur_frame_tiger = timestamp_scene % N_TIGER_FRAMES;
    cur_frame_ben = timestamp_scene % N_BEN_FRAMES;
    cur_frame_wolf = timestamp_scene % N_WOLF_FRAMES;
    cur_frame_spider = timestamp_scene % N_SPIDER_FRAMES;
    
    glutPostRedisplay();

    glutTimerFunc(100, timer_scene, (timestamp_scene + 1) % INT_MAX);
}

void cleanup(void) {
    glDeleteVertexArrays(1, &axes_VAO);
    glDeleteBuffers(1, &axes_VBO);

    glDeleteVertexArrays(N_OBJECTS, object_VAO);
    glDeleteBuffers(N_OBJECTS, object_VBO);
}
// End of callback function definitions
#define CAM_TSPEED 0.05f


void set_ViewMatrix_for_world_viewer(void) {
    ViewMatrix = glm::mat4(camera_wv.uaxis.x, camera_wv.vaxis.x, camera_wv.naxis.x, 0.0f,
        camera_wv.uaxis.y, camera_wv.vaxis.y, camera_wv.naxis.y, 0.0f,
        camera_wv.uaxis.z, camera_wv.vaxis.z, camera_wv.naxis.z, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f);
    ViewMatrix = glm::translate(ViewMatrix, -camera_wv.pos);
}


void renew_cam_position(int del) {
    camera_wv.pos += CAM_TSPEED * del * (-camera_wv.naxis);
}

#define CAM_RSPEED 0.1f
void renew_cam_orientation_rotation_around_v_axis(int angle) {
    glm::mat3 RotationMatrix;

    RotationMatrix = glm::mat3(glm::rotate(glm::mat4(1.0f), CAM_RSPEED * TO_RADIAN * angle, camera_wv.vaxis));
    camera_wv.uaxis = RotationMatrix * camera_wv.uaxis;
    camera_wv.naxis = RotationMatrix * camera_wv.naxis;
}

void motion(int x, int y) {
    if (!camera_wv.move | (camera_type != CAMERA_WORLD_VIEWER))
        return;

    renew_cam_position(prevy - y);
    renew_cam_orientation_rotation_around_v_axis(prevx - x);

    prevx = x; prevy = y;

    set_ViewMatrix_for_world_viewer();
    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

    glutPostRedisplay();
}

void register_callbacks(void) {
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mousepress);
    glutReshapeFunc(reshape);
    glutMotionFunc(motion);
    glutTimerFunc(100, timer_scene, 0);
    glutCloseFunc(cleanup);
}

void initialize_OpenGL(void) {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHT1);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHTING);
  //  glEnable(GL_MULTISAMPLE);
   // glClearColor(100 / 255.0f, 100 / 255.0f, 100 / 255.0f, 1.0f); // Gray
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    
 
    PRP = glm::vec3(23.0f, 15.0f, 17.0f);
    VRP = glm::vec3(9.5f, 7.7f, 7.2f);
    VUP = glm::vec3(0.0f, 1.0f, 0.0f);
    VPN = PRP - VRP;
    lookat_n = glm::normalize(VPN);
    lookat_u = glm::normalize(glm::cross(VUP, VPN));
    lookat_v = glm::normalize(glm::cross(VPN, lookat_u));
   
    ViewMatrix = glm::lookAt(PRP,VRP, VUP);

    initialize_lights_and_material();
    initialize_flags();
    glGenTextures(N_TEXTURES_USED, texture_names);

   
    glm::vec4 Light_Position = { 0.0f, 500.0f, 0.0f, 1.0f };
    PRP = glm::vec3(23.0f, 15.0f, 17.0f);
    VRP = glm::vec3(9.5f, 7.7f, 7.2f);
    VUP = glm::vec3(0.0f, 1.0f, 0.0f);
    VPN = PRP - VRP;
    lookat_n = glm::normalize(VPN);
    lookat_u = glm::normalize(glm::cross(VUP, VPN));
    lookat_v = glm::normalize(glm::cross(VPN, lookat_u));

    ViewMatrix = glm::lookAt(PRP, VRP, VUP);
 //   ViewMatrix = glm::lookAt(glm::vec3(350.0f, 350.0f, 350.0f), glm::vec3(0.0f, 0.0f, 0.0f),
  //      glm::vec3(0.0f, 1.0f, 0.0f));
    glm::vec4 Light_Position_EC = ViewMatrix * Light_Position; // What is this line for?

    glUseProgram(h_ShaderProgram_PS);
    glUniform4fv(loc_Light_Position, 1, &Light_Position_EC[0]);
    glUniform3f(loc_Light_La, 0.5f, 0.5f, 0.5f);
    glUniform3f(loc_Light_L, 1.0f, 1.0f, 1.0f);

    fprintf(stdout, "^^^ Using the reflection vector for specular reflection...\n");
    use_halfway_vector = 0;
    glUniform1i(loc_use_halfway_vector, 0);
    glUseProgram(0);

}

void My_glTexImage2D_from_file(char* filename) {
    FREE_IMAGE_FORMAT tx_file_format;
    int tx_bits_per_pixel;
    FIBITMAP* tx_pixmap, * tx_pixmap_32;

    int width, height;
    GLvoid* data;

    tx_file_format = FreeImage_GetFileType(filename, 0);
    // assume everything is fine with reading texture from file: no error checking
    tx_pixmap = FreeImage_Load(tx_file_format, filename);
    tx_bits_per_pixel = FreeImage_GetBPP(tx_pixmap);

    fprintf(stdout, " * A %d-bit texture was read from %s.\n", tx_bits_per_pixel, filename);
    if (tx_bits_per_pixel == 32)
        tx_pixmap_32 = tx_pixmap;
    else {
        fprintf(stdout, " * Converting texture from %d bits to 32 bits...\n", tx_bits_per_pixel);
        tx_pixmap_32 = FreeImage_ConvertTo32Bits(tx_pixmap);
    }

    width = FreeImage_GetWidth(tx_pixmap_32);
    height = FreeImage_GetHeight(tx_pixmap_32);
    data = FreeImage_GetBits(tx_pixmap_32);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, data);
    fprintf(stdout, " * Loaded %dx%d RGBA texture into graphics memory.\n\n", width, height);

    FreeImage_Unload(tx_pixmap_32);
    if (tx_bits_per_pixel != 32)
        FreeImage_Unload(tx_pixmap);
}


void prepare_scene(void) {
    prepare_axes();
    prepare_floor();
    prepare_tiger();
    prepare_cow();
    prepare_ben();
    prepare_dragon();
    prepare_tank();
    prepare_godzilla();
    prepare_ironman();
    prepare_bus();
    prepare_wolf();
    prepare_bike();
    prepare_spider();
    set_up_scene_lights();
}

void initialize_renderer(void) {
    register_callbacks();
    prepare_shader_program();
    initialize_OpenGL();
    initialize_camera();
    prepare_scene();
  
   
}

void initialize_light() {
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    float Ambient[] = { 0.0f, 0.0f, 0.2f, 0.0f };
    float Diffuse[] = { 0.5f,0.5f,0.5f,0.0f };
    float Specular[] = { 0.5f,0.5f,0.5f,0.0f };
    float Position[] = { 10.0f,10.0f,30.0f,1.0f };

    glClearColor(0, 0, 0, 0);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glFrontFace(GL_CCW);

    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_AMBIENT, Ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, Diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, Position);
    glEnable(GL_LIGHT0);

    float spotlightdirection[] = { 0.0f,-0.1f,0.0f };
    glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 80.0f);
    glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 80.0f);
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spotlightdirection);
}

void initialize_glew(void) {
    GLenum error;

    glewExperimental = GL_TRUE;

    error = glewInit();
    if (error != GLEW_OK) {
        fprintf(stderr, "Error: %s\n", glewGetErrorString(error));
        exit(-1);
    }
    fprintf(stdout, "*********************************************************\n");
    fprintf(stdout, " - GLEW version supported: %s\n", glewGetString(GLEW_VERSION));
    fprintf(stdout, " - OpenGL renderer: %s\n", glGetString(GL_RENDERER));
    fprintf(stdout, " - OpenGL version supported: %s\n", glGetString(GL_VERSION));
    fprintf(stdout, "*********************************************************\n\n");
}

void print_message(const char* m) {
    fprintf(stdout, "%s\n\n", m);
}

void greetings(char* program_name, char messages[][256], int n_message_lines) {
    fprintf(stdout, "**************************************************************\n\n");
    fprintf(stdout, "  PROGRAM NAME: %s\n\n", program_name);
    fprintf(stdout, "    This program was coded for CSE4170 students\n");
    fprintf(stdout, "      of Dept. of Comp. Sci. & Eng., Sogang University.\n\n");

    for (int i = 0; i < n_message_lines; i++)
        fprintf(stdout, "%s\n", messages[i]);
    fprintf(stdout, "\n**************************************************************\n\n");

    initialize_glew();
}



void initialize_camera(void) {
    camera_type = CAMERA_WORLD_VIEWER;

    camera_wv.uaxis = glm::vec3(ViewMatrix[0].x, ViewMatrix[1].x, ViewMatrix[2].x);
    camera_wv.vaxis = glm::vec3(ViewMatrix[0].y, ViewMatrix[1].y, ViewMatrix[2].y);
    camera_wv.naxis = glm::vec3(ViewMatrix[0].z, ViewMatrix[1].z, ViewMatrix[2].z);
    camera_wv.pos = -(ViewMatrix[3].x * camera_wv.uaxis + ViewMatrix[3].y * camera_wv.vaxis + ViewMatrix[3].z * camera_wv.naxis);

    camera_wv.move = 0;
    camera_wv.fovy = 30.0f, camera_wv.aspect_ratio = 1.0f; camera_wv.near_c = 5.0f; camera_wv.far_c = 10000.0f;

    ViewProjectionMatrix = ProjectionMatrix * ViewMatrix;

 
}




#define N_MESSAGE_LINES 2
void main(int argc, char* argv[]) {
    char program_name[64] = "Sogang CSE4170 (4.1) Simple 3D Transformations";
    char messages[N_MESSAGE_LINES][256] = { "    - Keys used: 'ESC'",
       "    - Mouse used: Left Butten Click"
    };

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutInitContextVersion(3, 3);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutCreateWindow(program_name);

    greetings(program_name, messages, N_MESSAGE_LINES);
    initialize_renderer();
   // initialize_light();
    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
    glutMainLoop();
}